# -*- coding: utf-8 -*-
"""
KeySet v5.0 State Manager
Аналог Zustand для управления состоянием через Qt Signals
"""

from __future__ import annotations
from typing import Any, Dict, List, Optional, Set
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
import json
import uuid

from PySide6.QtCore import QObject, Signal
from PySide6.QtWidgets import QApplication
from PySide6.QtGui import QIcon


@dataclass
class Phrase:
    """Модель фразы (аналог React TypeScript интерфейса)"""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    phrase: str = ""
    ws: int = 0
    qws: int = 0 
    bws: int = 0
    status: str = ""
    groupId: str = ""
    dateAdded: datetime = field(default_factory=datetime.now)
    tags: List[str] = field(default_factory=list)
    color: str = ""
    pinned: bool = False
    marked: bool = False
    history: List[Dict] = field(default_factory=list)
    quality: float = 0.0
    category: str = ""
    
    def to_dict(self) -> Dict[str, Any]:
        """Сериализация в словарь"""
        data = {
            'id': self.id,
            'phrase': self.phrase,
            'ws': self.ws,
            'qws': self.qws,
            'bws': self.bws,
            'status': self.status,
            'groupId': self.groupId,
            'dateAdded': self.dateAdded.isoformat(),
            'tags': self.tags,
            'color': self.color,
            'pinned': self.pinned,
            'marked': self.marked,
            'history': self.history,
            'quality': self.quality,
            'category': self.category
        }
        return data
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Phrase':
        """Десериализация из словаря"""
        return cls(
            id=data.get('id', str(uuid.uuid4())),
            phrase=data.get('phrase', ''),
            ws=data.get('ws', 0),
            qws=data.get('qws', 0),
            bws=data.get('bws', 0),
            status=data.get('status', ''),
            groupId=data.get('groupId', ''),
            dateAdded=datetime.fromisoformat(data.get('dateAdded', datetime.now().isoformat())),
            tags=data.get('tags', []),
            color=data.get('color', ''),
            pinned=data.get('pinned', False),
            marked=data.get('marked', False),
            history=data.get('history', []),
            quality=data.get('quality', 0.0),
            category=data.get('category', '')
        )


@dataclass
class Group:
    """Модель группы"""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    parentId: Optional[str] = None
    color: str = "#3B82F6"  # blue-500
    description: str = ""
    phraseCount: int = 0
    createdAt: datetime = field(default_factory=datetime.now)
    color: str = ""
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'id': self.id,
            'name': self.name,
            'parentId': self.parentId,
            'color': self.color,
            'description': self.description,
            'phraseCount': self.phraseCount,
            'createdAt': self.createdAt.isoformat()
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Group':
        return cls(
            id=data.get('id', str(uuid.uuid4())),
            name=data.get('name', ''),
            parentId=data.get('parentId'),
            color=data.get('color', '#3B82F6'),
            description=data.get('description', ''),
            phraseCount=data.get('phraseCount', 0),
            createdAt=datetime.fromisoformat(data.get('createdAt', datetime.now().isoformat()))
        )


@dataclass
class LogEntry:
    """Модель записи в лог"""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    level: str = "info"  # info, success, warning, error
    message: str = ""
    timestamp: datetime = field(default_factory=datetime.now)
    details: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'id': self.id,
            'level': self.level,
            'message': self.message,
            'timestamp': self.timestamp.isoformat(),
            'details': self.details
        }


class StateManager(QObject):
    """
    Централизованное управление состоянием (аналог Zustand)
    Использует Qt Signals для уведомления об изменениях
    """
    
    # Сигналы для уведомления об изменениях состояния
    phrases_changed = Signal(list)
    groups_changed = Signal(list)
    selected_phrases_changed = Signal(set)
    current_group_changed = Signal(str, list)
    activity_log_changed = Signal(list)
    process_progress_changed = Signal(float)
    
    # Модальные окна
    modal_state_changed = Signal(str, bool)
    
    def __init__(self):
        super().__init__()
        self._phrases: List[Phrase] = []
        self._groups: List[Group] = []
        self._selected_phrase_ids: Set[str] = set()
        self._current_group_id: Optional[str] = None
        self._activity_log: List[LogEntry] = []
        self._process_progress = 0.0
        self._modal_states: Dict[str, bool] = {}
        
        # История для undo/redo
        self._history_past: List[Dict[str, Any]] = []
        self._history_future: List[Dict[str, Any]] = []
        self._max_history_size = 50
        
        # Загружаем сохраненное состояние
        self._load_state()
        
    # === УПРАВЛЕНИЕ ФРАЗАМИ ===
    
    @property
    def phrases(self) -> List[Phrase]:
        """Получить все фразы"""
        return self._phrases.copy()
    
    @property
    def current_group_phrases(self) -> List[Phrase]:
        """Получить фразы текущей группы"""
        if not self._current_group_id:
            return self._phrases
        return [p for p in self._phrases if p.groupId == self._current_group_id]
    
    def add_phrases(self, phrases: List[Phrase]) -> None:
        """Добавить фразы"""
        self._save_to_history()
        
        for phrase in phrases:
            if not any(p.id == phrase.id for p in self._phrases):
                self._phrases.append(phrase)
        
        self.phrases_changed.emit(self._phrases)
        self._update_group_counts()
        
    def delete_phrases(self, phrase_ids: List[str]) -> None:
        """Удалить фразы"""
        self._save_to_history()
        
        self._phrases = [p for p in self._phrases if p.id not in phrase_ids]
        self._selected_phrase_ids.difference_update(phrase_ids)
        
        self.phrases_changed.emit(self._phrases)
        self.selected_phrases_changed.emit(self._selected_phrase_ids)
        self._update_group_counts()
        
    def update_phrase(self, phrase_id: str, updates: Dict[str, Any]) -> None:
        """Обновить фразу"""
        self._save_to_history()
        
        for phrase in self._phrases:
            if phrase.id == phrase_id:
                for key, value in updates.items():
                    setattr(phrase, key, value)
                break
        
        self.phrases_changed.emit(self._phrases)
    
    # === УПРАВЛЕНИЕ ГРУППАМИ ===
    
    @property
    def groups(self) -> List[Group]:
        """Получить все группы"""
        return self._groups.copy()
    
    def add_group(self, group: Group) -> None:
        """Добавить группу"""
        self._save_to_history()
        self._groups.append(group)
        self.groups_changed.emit(self._groups)
        
    def update_group(self, group_id: str, updates: Dict[str, Any]) -> None:
        """Обновить группу"""
        self._save_to_history()
        
        for group in self._groups:
            if group.id == group_id:
                for key, value in updates.items():
                    setattr(group, key, value)
                break
        
        self.groups_changed.emit(self._groups)
        
    def move_phrases_to_group(self, phrase_ids: List[str], target_group_id: str) -> None:
        """Переместить фразы в группу"""
        self._save_to_history()
        
        for phrase in self._phrases:
            if phrase.id in phrase_ids:
                phrase.groupId = target_group_id
        
        self.phrases_changed.emit(self._phrases)
        self._update_group_counts()
        
    # === ВЫБОР ===
    
    @property
    def selected_phrase_ids(self) -> Set[str]:
        """Получить ID выбранных фраз"""
        return self._selected_phrase_ids.copy()
    
    def select_phrase(self, phrase_id: str) -> None:
        """Выбрать одну фразу"""
        self._selected_phrase_ids = {phrase_id}
        self.selected_phrases_changed.emit(self._selected_phrase_ids)
        
    def select_all(self) -> None:
        """Выбрать все фразы"""
        self._selected_phrase_ids = {p.id for p in self.current_group_phrases}
        self.selected_phrases_changed.emit(self._selected_phrase_ids)
        
    def clear_selection(self) -> None:
        """Очистить выбор"""
        self._selected_phrase_ids.clear()
        self.selected_phrases_changed.emit(self._selected_phrase_ids)
        
    def invert_selection(self) -> None:
        """Инвертировать выбор"""
        current_ids = {p.id for p in self.current_group_phrases}
        self._selected_phrase_ids = current_ids - self._selected_phrase_ids
        self.selected_phrases_changed.emit(self._selected_phrase_ids)
        
    # === ГРУППЫ ===
    
    @property
    def current_group_id(self) -> Optional[str]:
        """Получить ID текущей группы"""
        return self._current_group_id
        
    def set_current_group(self, group_id: Optional[str]) -> None:
        """Установить текущую группу"""
        self._current_group_id = group_id
        phrases = self.current_group_phrases
        self.current_group_changed.emit(group_id or "", phrases)
        
    # === ЛОГ АКТИВНОСТИ ===
    
    def add_log(self, level: str, message: str, details: Optional[Dict[str, Any]] = None) -> None:
        """Добавить запись в лог"""
        log_entry = LogEntry(
            level=level,
            message=message,
            details=details or {}
        )
        self._activity_log.append(log_entry)
        
        # Ограничиваем размер лога
        if len(self._activity_log) > 1000:
            self._activity_log = self._activity_log[-500:]
            
        self.activity_log_changed.emit(self._activity_log)
        
    @property
    def activity_log(self) -> List[LogEntry]:
        """Получить лог активности"""
        return self._activity_log.copy()
        
    # === МОДАЛЬНЫЕ ОКНА ===
    
    def set_modal_open(self, modal_name: str, is_open: bool) -> None:
        """Установить состояние модального окна"""
        self._modal_states[modal_name] = is_open
        self.modal_state_changed.emit(modal_name, is_open)
        
    def is_modal_open(self, modal_name: str) -> bool:
        """Проверить, открыто ли модальное окно"""
        return self._modal_states.get(modal_name, False)
        
    # === ПРОГРЕСС ===
    
    @property
    def process_progress(self) -> float:
        """Получить прогресс процесса"""
        return self._process_progress
        
    def set_process_progress(self, progress: float) -> None:
        """Установить прогресс процесса (0.0 - 1.0)"""
        self._process_progress = max(0.0, min(1.0, progress))
        self.process_progress_changed.emit(self._process_progress)
        
    # === ИСТОРИЯ UNDO/REDO ===
    
    def undo(self) -> bool:
        """Отменить последнее действие"""
        if not self._history_past:
            return False
            
        current_state = self._serialize_state()
        self._history_future.append(current_state)
        
        previous_state = self._history_past.pop()
        self._restore_state(previous_state)
        return True
        
    def redo(self) -> bool:
        """Повторить отмененное действие"""
        if not self._history_future:
            return False
            
        current_state = self._serialize_state()
        self._history_past.append(current_state)
        
        next_state = self._history_future.pop()
        self._restore_state(next_state)
        return True
        
    def can_undo(self) -> bool:
        """Можно ли отменить действие"""
        return len(self._history_past) > 0
        
    def can_redo(self) -> bool:
        """Можно ли повторить действие"""
        return len(self._history_future) > 0
        
    # === СОХРАНЕНИЕ/ЗАГРУЗКА ===
    
    def _save_to_history(self) -> None:
        """Сохранить текущее состояние в историю"""
        state = self._serialize_state()
        self._history_past.append(state)
        
        if len(self._history_past) > self._max_history_size:
            self._history_past = self._history_past[-self._max_history_size//2:]
            
        # Очистить redo историю при новом действии
        self._history_future.clear()
        
    def _serialize_state(self) -> Dict[str, Any]:
        """Сериализовать текущее состояние"""
        return {
            'phrases': [p.to_dict() for p in self._phrases],
            'groups': [g.to_dict() for g in self._groups],
            'selected_phrase_ids': list(self._selected_phrase_ids),
            'current_group_id': self._current_group_id
        }
        
    def _restore_state(self, state: Dict[str, Any]) -> None:
        """Восстановить состояние из сериализованных данных"""
        self._phrases = [Phrase.from_dict(p) for p in state.get('phrases', [])]
        self._groups = [Group.from_dict(g) for g in state.get('groups', [])]
        self._selected_phrase_ids = set(state.get('selected_phrase_ids', []))
        self._current_group_id = state.get('current_group_id')
        
        # Уведомить об изменениях
        self.phrases_changed.emit(self._phrases)
        self.groups_changed.emit(self._groups)
        self.selected_phrases_changed.emit(self._selected_phrase_ids)
        self.current_group_changed.emit(self._current_group_id or "", self.current_group_phrases)
        
    def _update_group_counts(self) -> None:
        """Обновить счетчики фраз в группах"""
        for group in self._groups:
            group.phraseCount = len([p for p in self._phrases if p.groupId == group.id])
        self.groups_changed.emit(self._groups)
        
    def _load_state(self) -> None:
        """Загрузить состояние из файла"""
        state_file = Path("keyset_v5_state.json")
        if state_file.exists():
            try:
                with open(state_file, 'r', encoding='utf-8') as f:
                    state_data = json.load(f)
                self._restore_state(state_data)
                self.add_log('info', 'Состояние загружено')
            except Exception as e:
                self.add_log('warning', f'Ошибка загрузки состояния: {e}')
                
    def save_state(self) -> None:
        """Сохранить состояние в файл"""
        try:
            state_data = self._serialize_state()
            state_file = Path("keyset_v5_state.json")
            with open(state_file, 'w', encoding='utf-8') as f:
                json.dump(state_data, f, ensure_ascii=False, indent=2)
            self.add_log('info', 'Состояние сохранено')
        except Exception as e:
            self.add_log('error', f'Ошибка сохранения состояния: {e}')


# Глобальный экземпляр менеджера состояния
_state_manager: Optional[StateManager] = None


def get_state_manager() -> StateManager:
    """Получить глобальный экземпляр StateManager"""
    global _state_manager
    if _state_manager is None:
        _state_manager = StateManager()
    return _state_manager
