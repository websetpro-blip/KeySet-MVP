# -*- coding: utf-8 -*-
"""
KeySet v5.0 Integration Module
Интеграция современного интерфейса в существующий KeySet app
"""

from __future__ import annotations

from typing import Optional

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QPushButton,
    QLabel,
    QMessageBox,
    QFrame
)

from .main_window import KeySetV5MainWindow
from .store.state_manager import get_state_manager


class KeySetV5Tab(QWidget):
    """
    Вкладка KeySet v5.0 для интеграции в существующий TabWidget
    """
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        # Layout для вкладки
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(0, 0, 0, 0)
        self.layout.setSpacing(0)
        
        # Widget с современным интерфейсом
        self.v5_window = None
        
        # Загрузка интерфейса при показе вкладки
        self._setup_ui()
        
    def _setup_ui(self):
        """Настройка интерфейса"""
        
        # Фон вкладки
        self.setStyleSheet("""
            QWidget {
                background-color: #F8F9FA;
            }
        """)
        
        # Заголовок вкладки
        header = QWidget()
        header.setMinimumHeight(60)
        header.setMaximumHeight(60)
        header.setStyleSheet("""
            QWidget {
                background-color: white;
                border-bottom: 1px solid #E5E7EB;
                padding: 12px 16px;
            }
        """)
        
        header_layout = QVBoxLayout(header)
        
        title = QLabel("KeySet v5.0 - Современный интерфейс")
        title.setStyleSheet("""
            QLabel {
                color: #1F2937;
                font-size: 16px;
                font-weight: 600;
            }
        """)
        header_layout.addWidget(title)
        
        subtitle = QLabel("Переработанный интерфейс с современным дизайном и расширенной функциональностью")
        subtitle.setStyleSheet("""
            QLabel {
                color: #6B7280;
                font-size: 12px;
            }
        """)
        header_layout.addWidget(subtitle)
        
        self.layout.addWidget(header)
        
        # Панель с информацией
        info_panel = QFrame()
        info_panel.setStyleSheet("""
            QFrame {
                background-color: #F0F9FF;
                border: 1px solid #BFDBFE;
                border-radius: 8px;
                margin: 16px;
                padding: 16px;
            }
        """)
        info_layout = QVBoxLayout(info_panel)
        
        info_title = QLabel("🚀 Новое в KeySet v5.0")
        info_title.setStyleSheet("""
            QLabel {
                color: #1E40AF;
                font-size: 14px;
                font-weight: 600;
            }
        """)
        info_layout.addWidget(info_title)
        
        features = [
            "✓ Современный интерфейс в стиле Gray Scale",
            "✓ Улучшенная таблица с продвинутой сортировкой",
            "✓ Drag & Drop между группами",
            "✓ Панель массовых операций",
            "✓ 23 модальных окна с расширенным функционалом",
            "✓ Горячие клавиши для быстрых действий",
            "✓ Система тегов и снапшотов",
            "✓ Автоматизированные пайплайны обработки",
            "✓ Кросс-минусация и морфологические дубли",
            "✓ Анализ качества данных"
        ]
        
        for feature in features:
            label = QLabel(feature)
            label.setStyleSheet("""
                QLabel {
                    color: #374151;
                    font-size: 11px;
                    padding: 2px 0px;
                }
            """)
            info_layout.addWidget(label)
        
        self.layout.addWidget(info_panel)
        
        # Кнопка запуска
        launch_panel = QWidget()
        launch_layout = QVBoxLayout(launch_panel)
        
        btn_launch = QPushButton("Запустить KeySet v5.0")
        btn_launch.setMinimumHeight(50)
        btn_launch.setStyleSheet("""
            QPushButton {
                background-color: #3B82F6;
                color: white;
                border: none;
                border-radius: 8px;
                font-size: 14px;
                font-weight: 600;
                margin: 0px 16px;
            }
            QPushButton:hover {
                background-color: #2563EB;
            }
            QPushButton:pressed {
                background-color: #1D4ED8;
            }
        """)
        btn_launch.clicked.connect(self._launch_v5_interface)
        
        launch_layout.addWidget(btn_launch)
        self.layout.addWidget(launch_panel)
        
        # Растяжка
        self.layout.addStretch()
        
    def _launch_v5_interface(self):
        """Запустить интерфейс v5.0"""
        try:
            # Создаем окно v5.0
            if self.v5_window is None:
                self.v5_window = KeySetV5MainWindow()
                
            # Показываем окно
            self.v5_window.show()
            self.v5_window.raise_()
            self.v5_window.activateWindow()
            
            # Сообщение об успехе
            QMessageBox.information(
                self,
                "KeySet v5.0",
                "Интерфейс KeySet v5.0 запущен!\n\n"
                "Все данные сохраняются автоматически.\n"
                "Используйте горячие клавиши для быстрой работы.\n\n"
                "Ctrl+A - выбрать все\n"
                "Delete - удалить выделенное\n"
                "Ctrl+Z - отмена\n"
                "Ctrl+F - поиск"
            )
            
        except Exception as e:
            QMessageBox.critical(
                self,
                "Ошибка",
                f"Не удалось запустить KeySet v5.0:\n\n{str(e)}"
            )
            
    def closeEvent(self, event):
        """Обработка закрытия вкладки"""
        # Сохраняем состояние v5 интерфейса
        try:
            if self.v5_window:
                self.state_manager = get_state_manager()
                self.state_manager.save_state()
        except Exception as e:
            print(f"Ошибка сохранения состояния: {e}")
            
        event.accept()
