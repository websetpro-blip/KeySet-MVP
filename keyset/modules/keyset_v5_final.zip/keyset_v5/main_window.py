# -*- coding: utf-8 -*-
"""
KeySet v5.0 Main Window
Главное окно с современным интерфейсом в стиле React версии
"""

from __future__ import annotations
from typing import List, Optional

from PySide6.QtCore import Qt, QSize
from PySide6.QtGui import QAction, QIcon, QKeySequence, QFont, QShortcut
from PySide6.QtWidgets import (
    QMainWindow, 
    QWidget, 
    QVBoxLayout, 
    QHBoxLayout, 
    QSplitter, 
    QLabel,
    QLineEdit,
    QFrame,
    QStatusBar,
    QProgressBar,
    QTabWidget,
    QTextEdit,
    QGroupBox,
    QListWidget,
    QListWidgetItem,
    QPushButton
)

from .components.toolbar import KeySetV5Toolbar
from .components.phrases_table import PhrasesTable
from .store.state_manager import Phrase, Group, get_state_manager


class GroupsPanel(QWidget):
    """Панель групп фраз (аналог React GroupsPanel)"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumWidth(280)
        self.setMaximumWidth(400)
        self.setStyleSheet("""
            QWidget {
                background-color: #F9FAFB;
                border: 1px solid #E5E7EB;
                border-radius: 6px;
            }
        """)
        
        self.state_manager = get_state_manager()
        
        # Настройка layout
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(0, 0, 0, 0)
        self.layout.setSpacing(0)
        
        # Заголовок
        header = QWidget()
        header.setMinimumHeight(40)
        header.setStyleSheet("""
            QWidget {
                background-color: #F3F4F6;
                border-bottom: 1px solid #E5E7EB;
                padding: 8px 12px;
            }
        """)
        header_layout = QHBoxLayout(header)
        
        title = QLabel("Группы фраз")
        title.setStyleSheet("""
            QLabel {
                color: #374151;
                font-weight: 600;
                font-size: 12px;
            }
        """)
        header_layout.addWidget(title)
        
        header_layout.addStretch()
        
        btn_add = QPushButton("+")
        btn_add.setMaximumWidth(30)
        btn_add.setStyleSheet("""
            QPushButton {
                background-color: #3B82F6;
                color: white;
                border: none;
                border-radius: 4px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #2563EB;
            }
        """)
        btn_add.clicked.connect(self._add_group)
        header_layout.addWidget(btn_add)
        
        self.layout.addWidget(header)
        
        # Список групп
        self.groups_list = QListWidget()
        self.groups_list.setStyleSheet("""
            QListWidget {
                background-color: transparent;
                border: none;
                outline: none;
            }
            QListWidget::item {
                padding: 8px 12px;
                border-bottom: 1px solid #F3F4F6;
            }
            QListWidget::item:hover {
                background-color: #F3F4F6;
            }
            QListWidget::item:selected {
                background-color: #3B82F6;
                color: white;
            }
        """)
        self.groups_list.itemSelectionChanged.connect(self._on_group_selected)
        
        self.layout.addWidget(self.groups_list)
        
        # Подключение к state manager
        self.state_manager.groups_changed.connect(self._update_groups)
        self.state_manager.current_group_changed.connect(self._update_current_group)
        
        # Загрузка групп
        self._update_groups(self.state_manager.groups)
        
    def _add_group(self):
        """Добавить новую группу"""
        group = Group(name=f"Новая группа {len(self.state_manager.groups) + 1}")
        self.state_manager.add_group(group)
        
    def _on_group_selected(self):
        """Обработка выбора группы"""
        current_item = self.groups_list.currentItem()
        if current_item:
            group_id = current_item.data(Qt.UserRole)
            self.state_manager.set_current_group(group_id)
            
    def _update_groups(self, groups: List[Group]):
        """Обновить список групп"""
        self.groups_list.clear()
        
        # Добавляем "Все группы"
        all_item = QListWidgetItem("📂 Все группы")
        all_item.setData(Qt.UserRole, "")
        self.groups_list.addItem(all_item)
        
        # Добавляем группы
        for group in groups:
            item = QListWidgetItem(f"📁 {group.name} ({group.phraseCount})")
            item.setData(Qt.UserRole, group.id)
            self.groups_list.addItem(item)
            
    def _update_current_group(self, group_id: str, phrases: List[Phrase]):
        """Обновить выделение текущей группы"""
        for i in range(self.groups_list.count()):
            item = self.groups_list.item(i)
            if item.data(Qt.UserRole) == group_id:
                self.groups_list.setCurrentItem(item)
                break
                
        # Уведомляем о количестве фраз
        self.parent().update_phrases_count(len(phrases))


class ActivityLog(QWidget):
    """Лог активности (аналог React ActivityLog)"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(120)
        self.setMaximumHeight(200)
        self.setStyleSheet("""
            QWidget {
                background-color: white;
                border: 1px solid #E5E7EB;
                border-radius: 6px;
            }
        """)
        
        self.state_manager = get_state_manager()
        
        # Layout
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(8, 8, 8, 8)
        self.layout.setSpacing(4)
        
        # Заголовок
        header = QHBoxLayout()
        title = QLabel("Лог активности")
        title.setStyleSheet("""
            QLabel {
                color: #374151;
                font-weight: 600;
                font-size: 11px;
            }
        """)
        header.addWidget(title)
        
        header.addStretch()
        
        btn_clear = QPushButton("Очистить")
        btn_clear.setMaximumWidth(80)
        btn_clear.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: #6B7280;
                border: 1px solid #D1D5DB;
                border-radius: 4px;
                padding: 4px 8px;
                font-size: 10px;
            }
            QPushButton:hover {
                background-color: #F3F4F6;
                border-color: #9CA3AF;
            }
        """)
        btn_clear.clicked.connect(self._clear_log)
        header.addWidget(btn_clear)
        
        self.layout.addLayout(header)
        
        # Текстовое поле лога
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setMaximumHeight(100)
        self.log_text.setStyleSheet("""
            QTextEdit {
                background-color: #F9FAFB;
                border: 1px solid #E5E7EB;
                border-radius: 4px;
                padding: 8px;
                font-size: 10px;
                font-family: 'Consolas', 'Monaco', monospace;
            }
        """)
        self.layout.addWidget(self.log_text)
        
        # Подключение к state manager
        self.state_manager.activity_log_changed.connect(self._update_log)
        
        # Загрузка лога
        self._update_log(self.state_manager.activity_log)
        
    def _update_log(self, log_entries):
        """Обновить отображение лога"""
        self.log_text.clear()
        
        # Показываем последние 50 записей
        recent_entries = log_entries[-50:] if len(log_entries) > 50 else log_entries
        
        for entry in reversed(recent_entries):  # Показываем последние сначала
            # Форматируем сообщение в зависимости от уровня
            level_colors = {
                'info': '#6B7280',
                'success': '#059669', 
                'warning': '#D97706',
                'error': '#DC2626'
            }
            
            color = level_colors.get(entry.level, '#6B7280')
            
            # Форматируем время
            time_str = entry.timestamp.strftime("%H:%M:%S")
            
            message = f"<span style='color: {color}; font-weight: bold;'>[{time_str}]</span> {entry.message}"
            self.log_text.append(message)
            
        # Автопрокрутка вниз
        cursor = self.log_text.textCursor()
        cursor.movePosition(cursor.End)
        self.log_text.setTextCursor(cursor)
        
    def _clear_log(self):
        """Очистить лог"""
        self.log_text.clear()


class StatusBar(QWidget):
    """Строка состояния (аналог React StatusBar)"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(32)
        self.setMaximumHeight(32)
        self.setStyleSheet("""
            QWidget {
                background-color: #F3F4F6;
                border-top: 1px solid #E5E7EB;
            }
        """)
        
        self.state_manager = get_state_manager()
        
        # Layout
        self.layout = QHBoxLayout(self)
        self.layout.setContentsMargins(12, 4, 12, 4)
        
        # Информация о выделении
        self.selection_label = QLabel("Выбрано: 0 фраз")
        self.selection_label.setStyleSheet("""
            QLabel {
                color: #374151;
                font-size: 11px;
            }
        """)
        self.layout.addWidget(self.selection_label)
        
        # Разделитель
        separator1 = QFrame()
        separator1.setFrameShape(QFrame.VLine)
        separator1.setFrameShadow(QFrame.Sunken)
        self.layout.addWidget(separator1)
        
        # Общее количество фраз
        self.total_label = QLabel("Всего: 0 фраз")
        self.total_label.setStyleSheet("""
            QLabel {
                color: #6B7280;
                font-size: 11px;
            }
        """)
        self.layout.addWidget(self.total_label)
        
        # Разделитель
        separator2 = QFrame()
        separator2.setFrameShape(QFrame.VLine)
        separator2.setFrameShadow(QFrame.Sunken)
        self.layout.addWidget(separator2)
        
        # Прогресс-бар
        self.progress_bar = QProgressBar()
        self.progress_bar.setMaximumWidth(120)
        self.progress_bar.setMaximumHeight(16)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                background-color: #E5E7EB;
                border: 1px solid #D1D5DB;
                border-radius: 8px;
            }
            QProgressBar::chunk {
                background-color: #3B82F6;
                border-radius: 8px;
            }
        """)
        self.layout.addWidget(self.progress_bar)
        
        self.layout.addStretch()
        
        # Подключение к state manager
        self.state_manager.selected_phrases_changed.connect(self._update_selection)
        self.state_manager.phrases_changed.connect(self._update_total)
        self.state_manager.process_progress_changed.connect(self._update_progress)
        
        # Инициализация
        self._update_selection(self.state_manager.selected_phrase_ids)
        self._update_total(self.state_manager.phrases)
        
    def _update_selection(self, selected_ids):
        """Обновить информацию о выделении"""
        count = len(selected_ids)
        self.selection_label.setText(f"Выбрано: {count} фраз")
        
    def _update_total(self, phrases):
        """Обновить общее количество"""
        self.total_label.setText(f"Всего: {len(phrases)} фраз")
        
    def _update_progress(self, progress):
        """Обновить прогресс-бар"""
        self.progress_bar.setValue(int(progress * 100))


class KeySetV5MainWindow(QMainWindow):
    """Главное окно KeySet v5.0"""
    
    def __init__(self):
        super().__init__()
        
        # Настройка окна
        self.setWindowTitle("KeySet v5.0 - Современный интерфейс")
        self.setMinimumSize(1200, 800)
        self.resize(1400, 900)
        
        # Создаем центральный виджет
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Основной layout
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)
        
        # Toolbar
        self.toolbar = KeySetV5Toolbar()
        main_layout.addWidget(self.toolbar)
        
        # Поле поиска
        search_widget = QWidget()
        search_widget.setMinimumHeight(40)
        search_widget.setMaximumHeight(40)
        search_widget.setStyleSheet("""
            QWidget {
                background-color: #F9FAFB;
                border-bottom: 1px solid #E5E7EB;
                padding: 8px 12px;
            }
        """)
        
        search_layout = QHBoxLayout(search_widget)
        
        search_label = QLabel("Поиск:")
        search_label.setStyleSheet("""
            QLabel {
                color: #6B7280;
                font-size: 11px;
            }
        """)
        search_layout.addWidget(search_label)
        
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Введите фразу, тег или статус...")
        self.search_input.setStyleSheet("""
            QLineEdit {
                background-color: white;
                border: 1px solid #D1D5DB;
                border-radius: 6px;
                padding: 8px 12px;
                font-size: 11px;
            }
            QLineEdit:focus {
                border-color: #3B82F6;
            }
        """)
        self.search_input.textChanged.connect(self._on_search_changed)
        search_layout.addWidget(self.search_input)
        
        main_layout.addWidget(search_widget)
        
        # Основной контент
        content_widget = QWidget()
        content_layout = QHBoxLayout(content_widget)
        content_layout.setContentsMargins(12, 12, 12, 12)
        content_layout.setSpacing(12)
        
        # Левая панель (таблица + лог + статус)
        left_panel = QSplitter(Qt.Vertical)
        
        # Таблица фраз
        self.phrases_table = PhrasesTable()
        left_panel.addWidget(self.phrases_table)
        
        # Лог активности
        self.activity_log = ActivityLog()
        left_panel.addWidget(self.activity_log)
        
        # Размеры сплиттера
        left_panel.setSizes([500, 150])
        
        content_layout.addWidget(left_panel, 3)
        
        # Правая панель (группы)
        self.groups_panel = GroupsPanel()
        content_layout.addWidget(self.groups_panel, 1)
        
        main_layout.addWidget(content_widget)
        
        # Строка состояния
        self.status_bar = StatusBar()
        main_layout.addWidget(self.status_bar)
        
        # Подключение к state manager
        self.state_manager = get_state_manager()
        self._setup_callbacks()
        self._setup_hotkeys()
        
        # Загрузка данных
        self._load_initial_data()
        
    def _setup_callbacks(self):
        """Настройка callback'ов для toolbar"""
        callbacks = {
            'on_import': self._open_import_dialog,
            'on_export': self._open_export_dialog,
            'on_duplicates': self._open_duplicates_dialog,
            'on_statistics': self._open_statistics_dialog,
            'on_similar': self._open_similar_dialog,
            'on_parsing': self._open_parsing_dialog,
            'on_stopwords': self._open_stopwords_dialog,
            'on_filters': self._open_filters_dialog,
            'on_cross_minus': self._open_cross_minus_dialog,
            'on_automation': self._open_automation_dialog,
            'on_pipelines': self._open_pipelines_dialog,
            'on_snapshots': self._open_snapshots_dialog,
            'on_tags': self._open_tags_dialog,
            'on_undo': self._undo_action,
            'on_redo': self._redo_action,
            'on_refresh': self._refresh_data
        }
        
        self.toolbar.set_callbacks(callbacks)
        
    def _setup_hotkeys(self):
        """Настройка горячих клавиш"""
        # Ctrl+A - выбрать все
        QShortcut(QKeySequence("Ctrl+A"), self).activated.connect(
            lambda: self.phrases_table.selectAll()
        )
        
        # Delete - удалить выделенные
        QShortcut(QKeySequence("Delete"), self).activated.connect(
            lambda: self.phrases_table.keyPressEvent
        )
        
        # Escape - очистить выделение
        QShortcut(QKeySequence("Escape"), self).activated.connect(
            lambda: self.phrases_table.clearSelection()
        )
        
        # Ctrl+F - фокус на поиск
        QShortcut(QKeySequence("Ctrl+F"), self).activated.connect(
            lambda: self.search_input.setFocus()
        )
        
        # Ctrl+Z - отмена
        QShortcut(QKeySequence("Ctrl+Z"), self).activated.connect(self._undo_action)
        
        # Ctrl+Y - повтор
        QShortcut(QKeySequence("Ctrl+Y"), self).activated.connect(self._redo_action)
        
    def _on_search_changed(self, text):
        """Обработка изменения поиска"""
        self.phrases_table.set_filter(text)
        
    def focus_search(self):
        """Фокус на поле поиска"""
        self.search_input.setFocus()
        self.search_input.selectAll()
        
    def update_phrases_count(self, count):
        """Обновить количество фраз в groups panel"""
        # Этот метод вызывается из GroupsPanel
        pass
        
    # === ДИАЛОГИ ===
    
    def _open_import_dialog(self):
        """Открыть диалог импорта"""
        self.state_manager.set_modal_open('import', True)
        self.state_manager.add_log('info', 'Открыт диалог импорта')
        
    def _open_export_dialog(self):
        """Открыть диалог экспорта"""
        self.state_manager.set_modal_open('export', True)
        self.state_manager.add_log('info', 'Открыт диалог экспорта')
        
    def _open_duplicates_dialog(self):
        """Открыть поиск дубликатов"""
        self.state_manager.set_modal_open('duplicates', True)
        self.state_manager.add_log('info', 'Открыт поиск дубликатов')
        
    def _open_statistics_dialog(self):
        """Открыть статистику"""
        self.state_manager.set_modal_open('statistics', True)
        self.state_manager.add_log('info', 'Открыта статистика')
        
    def _open_similar_dialog(self):
        """Открыть поиск похожих"""
        self.state_manager.set_modal_open('similar_phrases', True)
        self.state_manager.add_log('info', 'Открыт поиск похожих')
        
    def _open_parsing_dialog(self):
        """Открыть парсинг"""
        self.state_manager.set_modal_open('parsing', True)
        self.state_manager.add_log('info', 'Открыт парсинг')
        
    def _open_stopwords_dialog(self):
        """Открыть управление стоп-словами"""
        self.state_manager.set_modal_open('stopwords', True)
        self.state_manager.add_log('info', 'Открыто управление стоп-словами')
        
    def _open_filters_dialog(self):
        """Открыть фильтры"""
        self.state_manager.set_modal_open('filters', True)
        self.state_manager.add_log('info', 'Открыты фильтры')
        
    def _open_cross_minus_dialog(self):
        """Открыть кросс-минусацию"""
        self.state_manager.set_modal_open('cross_minusation', True)
        self.state_manager.add_log('info', 'Открыта кросс-минусация')
        
    def _open_automation_dialog(self):
        """Открыть автоматизацию"""
        self.state_manager.set_modal_open('automation', True)
        self.state_manager.add_log('info', 'Открыта автоматизация')
        
    def _open_pipelines_dialog(self):
        """Открыть пайплайны"""
        self.state_manager.set_modal_open('pipelines', True)
        self.state_manager.add_log('info', 'Открыты пайплайны')
        
    def _open_snapshots_dialog(self):
        """Открыть снапшоты"""
        self.state_manager.set_modal_open('snapshots', True)
        self.state_manager.add_log('info', 'Открыты снапшоты')
        
    def _open_tags_dialog(self):
        """Открыть теги"""
        self.state_manager.set_modal_open('tags', True)
        self.state_manager.add_log('info', 'Открыто управление тегами')
        
    # === ACTIONS ===
    
    def _undo_action(self):
        """Отменить действие"""
        if self.state_manager.undo():
            self.state_manager.add_log('info', 'Действие отменено')
        else:
            self.state_manager.add_log('warning', 'Нет действий для отмены')
            
    def _redo_action(self):
        """Повторить действие"""
        if self.state_manager.redo():
            self.state_manager.add_log('info', 'Действие повторено')
        else:
            self.state_manager.add_log('warning', 'Нет действий для повторения')
            
    def _refresh_data(self):
        """Обновить данные"""
        self.state_manager.add_log('info', 'Данные обновлены')
        
    def _load_initial_data(self):
        """Загрузить начальные данные"""
        # Создаем тестовые данные для демонстрации
        if not self.state_manager.phrases:
            # Создаем тестовую группу
            test_group = Group(name="Тестовая группа")
            self.state_manager.add_group(test_group)
            
            # Создаем тестовые фразы
            test_phrases = [
                Phrase(phrase="купить смартфон", ws=10000, qws=5000, bws=2000, groupId=test_group.id),
                Phrase(phrase="как выбрать телефон", ws=5000, qws=2500, bws=1000, groupId=test_group.id),
                Phrase(phrase="лучшие смартфоны 2024", ws=8000, qws=4000, bws=1500, groupId=test_group.id),
                Phrase(phrase="обзор смартфонов", ws=3000, qws=1500, bws=800, groupId=test_group.id),
                Phrase(phrase="сравнение телефонов", ws=4000, qws=2000, bws=900, groupId=test_group.id),
            ]
            
            self.state_manager.add_phrases(test_phrases)
            self.state_manager.add_log('success', f'Загружено {len(test_phrases)} тестовых фраз')
