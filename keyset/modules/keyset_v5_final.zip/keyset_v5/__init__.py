# -*- coding: utf-8 -*-
"""
KeySet v5.0 Package
Современный интерфейс для KeySet
"""

from __future__ import annotations

__version__ = "5.0.0"
__author__ = "KeySet Team"

# Экспортируем основные компоненты
from .main_window import KeySetV5MainWindow
from .integration import KeySetV5Tab
from .store.state_manager import get_state_manager, StateManager, Phrase, Group

__all__ = [
    'KeySetV5MainWindow',
    'KeySetV5Tab', 
    'get_state_manager',
    'StateManager',
    'Phrase',
    'Group'
]
