# -*- coding: utf-8 -*-
"""
Тест KeySet v5.0
Проверка функциональности всех компонентов
"""

import sys
import time
from pathlib import Path

# Добавляем путь к файлам
current_dir = Path(__file__).parent
sys.path.insert(0, str(current_dir))

def test_state_manager():
    """Тестирование State Manager"""
    print("🔧 Тестирование State Manager...")
    
    try:
        from keyset_v5.store.state_manager import get_state_manager, Phrase, Group
        
        # Получаем state manager
        state = get_state_manager()
        
        # Тестируем создание группы
        group = Group(name="Тестовая группа")
        state.add_group(group)
        print(f"✅ Группа создана: {group.name}")
        
        # Тестируем создание фразы
        phrase = Phrase(
            phrase="тестовая фраза",
            ws=1000,
            qws=500,
            bws=200,
            groupId=group.id
        )
        state.add_phrases([phrase])
        print(f"✅ Фраза создана: {phrase.phrase}")
        
        # Тестируем выбор
        state.select_phrase(phrase.id)
        print(f"✅ Фраза выбрана: {len(state.selected_phrase_ids)} выбрано")
        
        # Тестируем лог
        state.add_log('success', 'Тестовое сообщение')
        print(f"✅ Лог добавлен: {len(state.activity_log)} записей")
        
        # Тестируем undo/redo
        state.add_log('info', 'Сообщение для отмены')
        can_undo = state.can_undo()
        print(f"✅ Undo доступен: {can_undo}")
        
        if can_undo:
            state.undo()
            print("✅ Undo выполнен")
        
        return True
        
    except Exception as e:
        print(f"❌ Ошибка State Manager: {e}")
        return False

def test_components():
    """Тестирование компонентов UI"""
    print("🖼️  Тестирование UI компонентов...")
    
    try:
        from PySide6.QtWidgets import QApplication
        
        app = QApplication.instance()
        if app is None:
            app = QApplication([])
            
        # Тестируем Toolbar
        from keyset_v5.components.toolbar import KeySetV5Toolbar
        toolbar = KeySetV5Toolbar()
        print("✅ Toolbar создан")
        
        # Тестируем PhrasesTable
        from keyset_v5.components.phrases_table import PhrasesTable
        table = PhrasesTable()
        print("✅ PhrasesTable создан")
        
        # Тестируем MainWindow
        from keyset_v5.main_window import KeySetV5MainWindow
        window = KeySetV5MainWindow()
        print("✅ MainWindow создан")
        
        # Не показываем окно в тесте
        window.close()
        
        return True
        
    except Exception as e:
        print(f"❌ Ошибка UI компонентов: {e}")
        return False

def test_integration():
    """Тестирование интеграции"""
    print("🔗 Тестирование интеграции...")
    
    try:
        from keyset_v5.integration import KeySetV5Tab
        from PySide6.QtWidgets import QApplication
        
        app = QApplication.instance()
        if app is None:
            app = QApplication([])
            
        tab = KeySetV5Tab()
        print("✅ KeySetV5Tab создан")
        
        # Не показываем в тесте
        tab.deleteLater()
        
        return True
        
    except Exception as e:
        print(f"❌ Ошибка интеграции: {e}")
        return False

def test_morphological_algorithms():
    """Тестирование морфологических алгоритмов (если доступны)"""
    print("🔤 Тестирование морфологических алгоритмов...")
    
    try:
        # Проверяем наличие файлов морфологических алгоритмов
        morph_dir = Path("/workspace/keyset/core/morphology")
        if morph_dir.exists():
            print(f"✅ Морфологические алгоритмы найдены: {morph_dir}")
            
            # Проверяем содержимое
            morph_files = list(morph_dir.glob("*.py"))
            print(f"📄 Файлов в морфологии: {len(morph_files)}")
            
            # Тестируем импорт (если возможно)
            try:
                import importlib.util
                for file in morph_files[:3]:  # Тестируем первые 3 файла
                    spec = importlib.util.spec_from_file_location(file.stem, file)
                    if spec and spec.loader:
                        print(f"✅ Можно импортировать: {file.name}")
            except Exception as e:
                print(f"⚠️  Ошибка импорта морфологии: {e}")
                
        else:
            print("⚠️  Морфологические алгоритмы не найдены")
            
        return True
        
    except Exception as e:
        print(f"❌ Ошибка морфологических алгоритмов: {e}")
        return False

def run_all_tests():
    """Запуск всех тестов"""
    print("🧪 Запуск тестов KeySet v5.0")
    print("=" * 50)
    
    tests = [
        ("State Manager", test_state_manager),
        ("UI Components", test_components), 
        ("Integration", test_integration),
        ("Morphological Algorithms", test_morphological_algorithms)
    ]
    
    results = []
    
    for test_name, test_func in tests:
        print(f"\n🔍 Тест: {test_name}")
        print("-" * 30)
        
        start_time = time.time()
        success = test_func()
        end_time = time.time()
        
        duration = end_time - start_time
        results.append((test_name, success, duration))
        
        if success:
            print(f"✅ {test_name} пройден ({duration:.2f}s)")
        else:
            print(f"❌ {test_name} не пройден ({duration:.2f}s)")
    
    # Итоги
    print("\n" + "=" * 50)
    print("📊 РЕЗУЛЬТАТЫ ТЕСТИРОВАНИЯ")
    print("=" * 50)
    
    passed = 0
    total = len(results)
    
    for test_name, success, duration in results:
        status = "✅ ПРОЙДЕН" if success else "❌ НЕ ПРОЙДЕН"
        print(f"{test_name:.<30} {status:>15} ({duration:.2f}s)")
        if success:
            passed += 1
    
    print("-" * 50)
    print(f"Итого: {passed}/{total} тестов пройдено")
    
    if passed == total:
        print("\n🎉 Все тесты пройдены успешно!")
        print("🚀 KeySet v5.0 готов к использованию!")
        return True
    else:
        print(f"\n⚠️  {total - passed} тестов не пройдено")
        print("🔧 Проверьте ошибки выше")
        return False

if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
