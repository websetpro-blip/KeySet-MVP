#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Запуск KeySet v5.0 как standalone приложения
"""

import sys
import os
from pathlib import Path

# Добавляем путь к ключевым файлам
current_dir = Path(__file__).parent
sys.path.insert(0, str(current_dir.parent))

def main():
    """Главная функция запуска KeySet v5.0"""
    
    try:
        # Проверяем наличие PySide6
        try:
            from PySide6.QtCore import Qt
            from PySide6.QtWidgets import QApplication
        except ImportError:
            print("❌ PySide6 не установлен!")
            print("📦 Установите: pip install PySide6")
            return 1
            
        # Создаем приложение
        app = QApplication(sys.argv)
        app.setApplicationName("KeySet v5.0")
        app.setApplicationVersion("5.0.0")
        
        # Создаем и показываем окно
        from keyset_v5.main_window import KeySetV5MainWindow
        
        window = KeySetV5MainWindow()
        window.show()
        
        print("🚀 KeySet v5.0 запущен!")
        print("💡 Горячие клавиши:")
        print("   Ctrl+A - выбрать все")
        print("   Delete - удалить выделенное")
        print("   Ctrl+Z - отмена")
        print("   Ctrl+F - поиск")
        
        # Запускаем event loop
        return app.exec()
        
    except Exception as e:
        print(f"❌ Ошибка запуска KeySet v5.0: {e}")
        import traceback
        traceback.print_exc()
        return 1

if __name__ == "__main__":
    sys.exit(main())
