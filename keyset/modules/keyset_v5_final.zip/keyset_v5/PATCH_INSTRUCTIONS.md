# -*- coding: utf-8 -*-
"""
Patch для добавления вкладки KeySet v5.0 в существующий MainWindow
"""

# Добавляем импорт новой вкладки
# Добавьте эту строку в начало файла main.py (после импортов PySide6):

"""
try:
    from keyset_v5 import KeySetV5Tab
except ImportError:
    KeySetV5Tab = None
"""

# Найдите код создания вкладок в MainWindow.__init__() и добавьте после последней вкладки:

"""
# Добавляем вкладку KeySet v5.0 если доступна
if KeySetV5Tab:
    self.v5_tab = KeySetV5Tab()
    self.tabs.addTab(self.v5_tab, "KeySet v5.0")
    self.log_event("Добавлена вкладка KeySet v5.0")
else:
    self.log_event("KeySet v5.0 не найден - используется только основной интерфейс", level="WARN")
"""

# Также обновите обработчик _on_tab_changed для работы с новой вкладкой:

"""
def _on_tab_changed(self, index: int) -> None:
    """Обработчик переключения вкладок"""
    current_widget = self.tabs.widget(index)
    
    # Скрываем KeysPanel для вкладок Парсинг и KeySet v5.0 
    if (hasattr(self, 'parsing') and current_widget == self.parsing) or \
       (hasattr(self, 'v5_tab') and current_widget == self.v5_tab):
        self.keys_panel.hide()
    else:
        self.keys_panel.show()
"""
