# -*- coding: utf-8 -*-
"""
KeySet v5.0 Phrases Table Component
Аналог React PhrasesTable с TanStack функциональностью
"""

from __future__ import annotations
from typing import List, Optional, Callable, Dict, Any
import re

from PySide6.QtCore import Qt, QSortFilterProxyModel, QItemSelectionModel, pyqtSignal
from PySide6.QtGui import QStandardItemModel, QStandardItem, QColor, QFont
from PySide6.QtWidgets import (
    QTableWidget, 
    QTableWidgetItem, 
    QAbstractItemView,
    QHeaderView,
    QMenu,
    QLineEdit,
    QWidget,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QCheckBox
)

from ..store.state_manager import Phrase, get_state_manager


class PhraseTableItem(QTableWidgetItem):
    """Кастомный элемент таблицы для фраз"""
    
    def __init__(self, phrase: Phrase, column: str, parent=None):
        super().__init__(parent)
        self.phrase_id = phrase.id
        self.column = column
        
        # Устанавливаем значение в зависимости от столбца
        if column == 'phrase':
            self.setText(phrase.phrase)
        elif column == 'ws':
            self.setText(str(phrase.ws))
        elif column == 'qws':
            self.setText(str(phrase.qws))
        elif column == 'bws':
            self.setText(str(phrase.bws))
        elif column == 'status':
            self.setText(phrase.status)
        elif column == 'group':
            self.setText(phrase.groupId[:8] + '...' if len(phrase.groupId) > 11 else phrase.groupId)
        elif column == 'tags':
            self.setText(', '.join(phrase.tags))
        elif column == 'quality':
            self.setText(f"{phrase.quality:.2f}")
        
        # Устанавливаем цвета
        self._setup_colors(phrase)
        
    def _setup_colors(self, phrase: Phrase):
        """Настройка цветов элемента"""
        
        if phrase.pinned:
            self.setBackground(QColor(255, 248, 220))  # Лёгкий желтый для закрепленных
        elif phrase.marked:
            self.setBackground(QColor(240, 253, 244))  # Лёгкий зеленый для отмеченных
        
        # Цвет в зависимости от статуса
        if phrase.status:
            if phrase.status == 'ready':
                self.setForeground(QColor(34, 197, 94))  # Зеленый
            elif phrase.status == 'processing':
                self.setForeground(QColor(59, 130, 246))  # Синий
            elif phrase.status == 'error':
                self.setForeground(QColor(239, 68, 68))  # Красный
        
        # Качество - градиент от зеленого к красному
        if self.column == 'quality' and phrase.quality > 0:
            quality_ratio = phrase.quality / 100  # Предполагаем max = 100
            
            # От зеленого (высокое качество) к красному (низкое)
            if quality_ratio > 0.7:
                bg_color = QColor(34, 197, 94, 30)  # Зеленый прозрачный
            elif quality_ratio > 0.4:
                bg_color = QColor(251, 191, 36, 30)  # Желтый прозрачный
            else:
                bg_color = QColor(239, 68, 68, 30)  # Красный прозрачный
            
            self.setBackground(bg_color)


class PhrasesTable(QTableWidget):
    """Таблица фраз с функциональностью аналогичной React версии"""
    
    # Сигналы
    phrase_selected = pyqtSignal(str)  # phrase_id
    phrase_double_clicked = pyqtSignal(str)  # phrase_id
    context_menu_requested = pyqtSignal(dict)  # {phrase_id, position}
    selection_changed = pyqtSignal(list)  # list of phrase_ids
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        # Настройки таблицы
        self.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.setAlternatingRowColors(True)
        self.setSortingEnabled(True)
        self.setShowGrid(False)
        self.setWordWrap(False)
        
        # Настройка заголовков
        self.setColumnCount(8)
        headers = [
            "Фраза",
            "WS",
            "QWS", 
            "BWS",
            "Статус",
            "Группа",
            "Теги",
            "Качество"
        ]
        self.setHorizontalHeaderLabels(headers)
        
        # Настройка размеров колонок
        header = self.horizontalHeader()
        header.setStretchLastSection(True)
        self.setColumnWidth(0, 300)  # Фраза
        self.setColumnWidth(1, 60)   # WS
        self.setColumnWidth(2, 60)   # QWS
        self.setColumnWidth(3, 60)   # BWS
        self.setColumnWidth(4, 80)   # Статус
        self.setColumnWidth(5, 120)  # Группа
        self.setColumnWidth(6, 120)  # Теги
        self.setColumnWidth(7, 80)   # Качество
        
        # Подключение к state manager
        self.state_manager = get_state_manager()
        self.state_manager.phrases_changed.connect(self._update_phrases)
        self.state_manager.selected_phrases_changed.connect(self._update_selection)
        
        # Сохранение оригинального списка фраз
        self._all_phrases: List[Phrase] = []
        self._current_filter = ""
        
        # Установка стилей
        self._setup_styles()
        
        # Подключение сигналов
        self.itemSelectionChanged.connect(self._on_selection_changed)
        self.itemDoubleClicked.connect(self._on_item_double_clicked)
        self.setContextMenuPolicy(Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self._show_context_menu)
        
        # Клавиатурные сочетания
        self.keyPressEvent = self._handle_key_press
        
    def _setup_styles(self):
        """Настройка стилей таблицы"""
        self.setStyleSheet("""
            QTableWidget {
                background-color: white;
                alternate-background-color: #F9FAFB;
                border: 1px solid #E5E7EB;
                border-radius: 6px;
                gridline-color: #E5E7EB;
                selection-background-color: #3B82F6;
                selection-color: white;
                font-size: 11px;
            }
            
            QTableWidget::item {
                padding: 8px 12px;
                border-bottom: 1px solid #F3F4F6;
            }
            
            QTableWidget::item:selected {
                background-color: #3B82F6;
                color: white;
            }
            
            QHeaderView::section {
                background-color: #F3F4F6;
                color: #374151;
                padding: 8px 12px;
                border: none;
                border-bottom: 1px solid #D1D5DB;
                font-weight: 600;
            }
            
            QHeaderView::section:hover {
                background-color: #E5E7EB;
            }
            
            QScrollBar:vertical {
                background-color: #F9FAFB;
                width: 12px;
                border-radius: 6px;
            }
            
            QScrollBar::handle:vertical {
                background-color: #D1D5DB;
                border-radius: 6px;
                min-height: 20px;
            }
            
            QScrollBar::handle:vertical:hover {
                background-color: #9CA3AF;
            }
        """)
        
    def _update_phrases(self, phrases: List[Phrase]):
        """Обновить отображение фраз"""
        self._all_phrases = phrases
        
        # Применяем фильтр
        filtered_phrases = self._apply_filter(phrases)
        
        self.setRowCount(len(filtered_phrases))
        
        for row, phrase in enumerate(filtered_phrases):
            # Создаем элементы для каждой колонки
            columns = ['phrase', 'ws', 'qws', 'bws', 'status', 'group', 'tags', 'quality']
            
            for col, column_name in enumerate(columns):
                item = PhraseTableItem(phrase, column_name)
                self.setItem(row, col, item)
                
                # Устанавливаем выравнивание
                if column_name in ['ws', 'qws', 'bws', 'quality']:
                    item.setTextAlignment(Qt.AlignCenter)
                    
        self._update_selection(self.state_manager.selected_phrase_ids)
        
    def _apply_filter(self, phrases: List[Phrase]) -> List[Phrase]:
        """Применить фильтр по поисковой строке"""
        if not self._current_filter:
            return phrases
            
        filter_text = self._current_filter.lower()
        
        # Фильтруем фразы по ключевым словам
        filtered = []
        for phrase in phrases:
            if (filter_text in phrase.phrase.lower() or
                any(filter_text in tag.lower() for tag in phrase.tags) or
                filter_text in phrase.status.lower()):
                filtered.append(phrase)
                
        return filtered
        
    def _update_selection(self, selected_ids: set):
        """Обновить визуальное выделение"""
        # Очищаем все выделения
        self.clearSelection()
        
        # Устанавливаем выделение для выбранных фраз
        for row in range(self.rowCount()):
            item = self.item(row, 0)
            if item and item.phrase_id in selected_ids:
                self.selectRow(row)
                
    def _on_selection_changed(self):
        """Обработка изменения выделения"""
        selected_rows = self.selectionModel().selectedRows()
        selected_ids = []
        
        for index in selected_rows:
            item = self.item(index.row(), 0)
            if item:
                selected_ids.append(item.phrase_id)
                
        self.selection_changed.emit(selected_ids)
        
        # Уведомляем state manager
        if selected_ids:
            self.state_manager.select_phrase(selected_ids[0])
            
    def _on_item_double_clicked(self, item: PhraseTableItem):
        """Обработка двойного клика"""
        if item:
            self.phrase_double_clicked.emit(item.phrase_id)
            
    def _show_context_menu(self, position):
        """Показать контекстное меню"""
        item = self.itemAt(position)
        if item:
            menu = QMenu(self)
            
            # Действия контекстного меню
            action_pin = menu.addAction("Закрепить фразу")
            action_mark = menu.addAction("Отметить фразу")
            action_delete = menu.addAction("Удалить фразу")
            action_edit = menu.addAction("Редактировать")
            
            menu.addSeparator()
            action_copy = menu.addAction("Копировать фразу")
            action_search = menu.addAction("Поиск похожих")
            
            action = menu.exec(self.mapToGlobal(position))
            
            if action == action_pin:
                self._toggle_pin(item.phrase_id)
            elif action == action_mark:
                self._toggle_mark(item.phrase_id)
            elif action == action_delete:
                self._delete_phrase(item.phrase_id)
            elif action == action_edit:
                self._edit_phrase(item.phrase_id)
            elif action == action_copy:
                self._copy_phrase(item.phrase_id)
            elif action == action_search:
                self._search_similar(item.phrase_id)
                
    def _handle_key_press(self, event):
        """Обработка нажатий клавиш"""
        key = event.key()
        
        # Escape - очистить выделение
        if key == Qt.Key_Escape:
            self.clearSelection()
            self.state_manager.clear_selection()
            return
            
        # Delete - удалить выделенные фразы
        elif key == Qt.Key_Delete:
            selected_ids = self.state_manager.selected_phrase_ids
            if selected_ids:
                self.state_manager.delete_phrases(list(selected_ids))
                self.state_manager.add_log('info', f'Удалено {len(selected_ids)} фраз')
            return
            
        # Ctrl+A - выбрать все
        elif event.modifiers() == Qt.ControlModifier and key == Qt.Key_A:
            self.selectAll()
            self.state_manager.select_all()
            return
            
        # Ctrl+F - фокус на поиск
        elif event.modifiers() == Qt.ControlModifier and key == Qt.Key_F:
            self.parent().focus_search() if hasattr(self.parent(), 'focus_search') else None
            return
            
        # Вызов родительского обработчика
        super().keyPressEvent(event)
        
    def _toggle_pin(self, phrase_id: str):
        """Переключить закрепление фразы"""
        # Находим фразу и переключаем состояние
        for phrase in self._all_phrases:
            if phrase.id == phrase_id:
                phrase.pinned = not phrase.pinned
                self.state_manager.update_phrase(phrase_id, {'pinned': phrase.pinned})
                self.state_manager.add_log('info', f'Фраза {"закреплена" if phrase.pinned else "откреплена"}')
                break
                
    def _toggle_mark(self, phrase_id: str):
        """Переключить отметку фразы"""
        for phrase in self._all_phrases:
            if phrase.id == phrase_id:
                phrase.marked = not phrase.marked
                self.state_manager.update_phrase(phrase_id, {'marked': phrase.marked})
                self.state_manager.add_log('info', f'Фраза {"отмечена" if phrase.marked else "с отметки снята"}')
                break
                
    def _delete_phrase(self, phrase_id: str):
        """Удалить фразу"""
        self.state_manager.delete_phrases([phrase_id])
        self.state_manager.add_log('info', 'Фраза удалена')
        
    def _edit_phrase(self, phrase_id: str):
        """Редактировать фразу"""
        # Здесь можно открыть диалог редактирования
        self.state_manager.add_log('info', 'Открыт редактор фразы')
        
    def _copy_phrase(self, phrase_id: str):
        """Копировать фразу в буфер обмена"""
        for phrase in self._all_phrases:
            if phrase.id == phrase_id:
                # Копирование в буфер обмена
                import sys
                from PySide6.QtGui import QGuiApplication
                QGuiApplication.clipboard().setText(phrase.phrase)
                self.state_manager.add_log('success', 'Фраза скопирована в буфер')
                break
                
    def _search_similar(self, phrase_id: str):
        """Поиск похожих фраз"""
        self.state_manager.set_modal_open('similar_phrases', True)
        self.state_manager.add_log('info', 'Открыт поиск похожих фраз')
        
    def set_filter(self, filter_text: str):
        """Установить фильтр для таблицы"""
        self._current_filter = filter_text
        self._update_phrases(self._all_phrases)
        
    def get_selected_phrases(self) -> List[Phrase]:
        """Получить выделенные фразы"""
        selected_ids = self.state_manager.selected_phrase_ids
        return [phrase for phrase in self._all_phrases if phrase.id in selected_ids]
        
    def sort_by_column(self, column: int, order: Qt.SortOrder = Qt.AscendingOrder):
        """Сортировать по столбцу"""
        self.sortItems(column, order)
        
    def export_to_clipboard(self):
        """Экспортировать выделенные фразы в буфер обмена"""
        selected_phrases = self.get_selected_phrases()
        if not selected_phrases:
            return
            
        text_data = []
        for phrase in selected_phrases:
            line = f"{phrase.phrase}\t{phrase.ws}\t{phrase.qws}\t{phrase.bws}"
            text_data.append(line)
            
        from PySide6.QtGui import QGuiApplication
        QGuiApplication.clipboard().setText('\n'.join(text_data))
        self.state_manager.add_log('success', f'Экспортировано {len(selected_phrases)} фраз в буфер')
