# -*- coding: utf-8 -*-
"""
KeySet v5.0 Toolbar Component
Аналог React Toolbar с Gray Scale дизайном
"""

from __future__ import annotations
from typing import Optional, Callable

from PySide6.QtCore import Qt, QSize
from PySide6.QtGui import QAction, QIcon, QPixmap
from PySide6.QtWidgets import (
    QToolBar, 
    QPushButton, 
    QToolButton, 
    QMenu, 
    QHBoxLayout,
    QWidget,
    QLabel
)


class ModernButton(QPushButton):
    """Современная кнопка в стиле Gray Scale"""
    
    def __init__(self, text: str = "", icon: Optional[QIcon] = None, parent=None):
        super().__init__(text, parent)
        if icon:
            self.setIcon(icon)
        self.setIconSize(QSize(16, 16))
        self.setMinimumHeight(32)
        self.setMaximumHeight(32)
        self.setStyleSheet("""
            QPushButton {
                background-color: #F9FAFB;
                color: #374151;
                border: 1px solid #E5E7EB;
                border-radius: 6px;
                padding: 6px 12px;
                font-size: 11px;
                font-weight: 500;
            }
            QPushButton:hover {
                background-color: #F3F4F6;
                border-color: #D1D5DB;
            }
            QPushButton:pressed {
                background-color: #E5E7EB;
            }
            QPushButton:checked {
                background-color: #3B82F6;
                color: white;
                border-color: #2563EB;
            }
        """)


class ModernToolButton(QToolButton):
    """Современная кнопка инструмента"""
    
    def __init__(self, icon: Optional[QIcon] = None, parent=None):
        super().__init__(parent)
        if icon:
            self.setIcon(icon)
        self.setIconSize(QSize(18, 18))
        self.setMinimumSize(36, 32)
        self.setMaximumSize(36, 32)
        self.setStyleSheet("""
            QToolButton {
                background-color: #F9FAFB;
                border: 1px solid #E5E7EB;
                border-radius: 6px;
                padding: 4px;
            }
            QToolButton:hover {
                background-color: #F3F4F6;
                border-color: #D1D5DB;
            }
            QToolButton:pressed {
                background-color: #E5E7EB;
            }
        """)


class KeySetV5Toolbar(QWidget):
    """
    Главная панель инструментов KeySet v5.0
    Содержит все основные действия из React версии
    """
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(48)
        self.setMaximumHeight(48)
        
        # Создаем layout
        self.layout = QHBoxLayout(self)
        self.layout.setContentsMargins(12, 8, 12, 8)
        self.layout.setSpacing(8)
        
        # Флаги для callback'ов
        self._callbacks = {}
        
        self._setup_ui()
        
    def _setup_ui(self):
        """Настройка интерфейса"""
        
        # Группа файловых операций
        self._add_section_label("Файл")
        self.btn_import = ModernButton("Импорт", None)
        self.btn_export = ModernButton("Экспорт", None)
        self.layout.addWidget(self.btn_import)
        self.layout.addWidget(self.btn_export)
        
        # Разделитель
        self._add_separator()
        
        # Группа анализа
        self._add_section_label("Анализ")
        self.btn_duplicates = ModernButton("Дубликаты", None)
        self.btn_statistics = ModernButton("Статистика", None)
        self.btn_similar = ModernButton("Похожие", None)
        self.layout.addWidget(self.btn_duplicates)
        self.layout.addWidget(self.btn_statistics)
        self.layout.addWidget(self.btn_similar)
        
        # Разделитель
        self._add_separator()
        
        # Группа обработки
        self._add_section_label("Обработка")
        self.btn_parsing = ModernButton("Парсинг", None)
        self.btn_stopwords = ModernButton("Стоп-слова", None)
        self.btn_filters = ModernButton("Фильтры", None)
        self.btn_cross_minus = ModernButton("Кросс-минусация", None)
        self.layout.addWidget(self.btn_parsing)
        self.layout.addWidget(self.btn_stopwords)
        self.layout.addWidget(self.btn_filters)
        self.layout.addWidget(self.btn_cross_minus)
        
        # Разделитель
        self._add_separator()
        
        # Группа расширенных функций
        self._add_section_label("Инструменты")
        self.btn_automation = ModernButton("Автоматизация", None)
        self.btn_pipelines = ModernButton("Пайплайны", None)
        self.btn_snapshots = ModernButton("Снапшоты", None)
        self.btn_tags = ModernButton("Теги", None)
        self.layout.addWidget(self.btn_automation)
        self.layout.addWidget(self.btn_pipelines)
        self.layout.addWidget(self.btn_snapshots)
        self.layout.addWidget(self.btn_tags)
        
        # Растяжка
        self.layout.addStretch()
        
        # Группа быстрых действий
        self._add_section_label("Быстро")
        self.btn_undo = ModernToolButton(None)
        self.btn_redo = ModernToolButton(None)
        self.btn_refresh = ModernToolButton(None)
        self.layout.addWidget(self.btn_undo)
        self.layout.addWidget(self.btn_redo)
        self.layout.addWidget(self.btn_refresh)
        
    def _add_section_label(self, text: str):
        """Добавить метку секции"""
        label = QLabel(text)
        label.setStyleSheet("""
            QLabel {
                color: #6B7280;
                font-size: 10px;
                font-weight: 600;
                padding: 0px 4px;
            }
        """)
        label.setAlignment(Qt.AlignCenter)
        label.setMinimumWidth(50)
        self.layout.addWidget(label)
        
    def _add_separator(self):
        """Добавить разделитель"""
        separator = QWidget()
        separator.setMaximumWidth(1)
        separator.setMinimumHeight(24)
        separator.setStyleSheet("background-color: #E5E7EB;")
        self.layout.addWidget(separator)
        
    def _setup_callbacks(self):
        """Настройка callback'ов для всех кнопок"""
        
        # Файловые операции
        if 'on_import' in self._callbacks:
            self.btn_import.clicked.connect(self._callbacks['on_import'])
        if 'on_export' in self._callbacks:
            self.btn_export.clicked.connect(self._callbacks['on_export'])
            
        # Анализ
        if 'on_duplicates' in self._callbacks:
            self.btn_duplicates.clicked.connect(self._callbacks['on_duplicates'])
        if 'on_statistics' in self._callbacks:
            self.btn_statistics.clicked.connect(self._callbacks['on_statistics'])
        if 'on_similar' in self._callbacks:
            self.btn_similar.clicked.connect(self._callbacks['on_similar'])
            
        # Обработка
        if 'on_parsing' in self._callbacks:
            self.btn_parsing.clicked.connect(self._callbacks['on_parsing'])
        if 'on_stopwords' in self._callbacks:
            self.btn_stopwords.clicked.connect(self._callbacks['on_stopwords'])
        if 'on_filters' in self._callbacks:
            self.btn_filters.clicked.connect(self._callbacks['on_filters'])
        if 'on_cross_minus' in self._callbacks:
            self.btn_cross_minus.clicked.connect(self._callbacks['on_cross_minus'])
            
        # Инструменты
        if 'on_automation' in self._callbacks:
            self.btn_automation.clicked.connect(self._callbacks['on_automation'])
        if 'on_pipelines' in self._callbacks:
            self.btn_pipelines.clicked.connect(self._callbacks['on_pipelines'])
        if 'on_snapshots' in self._callbacks:
            self.btn_snapshots.clicked.connect(self._callbacks['on_snapshots'])
        if 'on_tags' in self._callbacks:
            self.btn_tags.clicked.connect(self._callbacks['on_tags'])
            
        # Быстрые действия
        if 'on_undo' in self._callbacks:
            self.btn_undo.clicked.connect(self._callbacks['on_undo'])
        if 'on_redo' in self._callbacks:
            self.btn_redo.clicked.connect(self._callbacks['on_redo'])
        if 'on_refresh' in self._callbacks:
            self.btn_refresh.clicked.connect(self._callbacks['on_refresh'])
            
    # === ПУБЛИЧНЫЕ МЕТОДЫ ===
    
    def set_callbacks(self, callbacks: dict[str, Callable]):
        """Установить callback'и для всех кнопок"""
        self._callbacks = callbacks
        self._setup_callbacks()
        
    def set_button_enabled(self, button_name: str, enabled: bool):
        """Установить состояние кнопки"""
        button_map = {
            'import': self.btn_import,
            'export': self.btn_export,
            'duplicates': self.btn_duplicates,
            'statistics': self.btn_statistics,
            'similar': self.btn_similar,
            'parsing': self.btn_parsing,
            'stopwords': self.btn_stopwords,
            'filters': self.btn_filters,
            'cross_minus': self.btn_cross_minus,
            'automation': self.btn_automation,
            'pipelines': self.btn_pipelines,
            'snapshots': self.btn_snapshots,
            'tags': self.btn_tags,
            'undo': self.btn_undo,
            'redo': self.btn_redo,
            'refresh': self.btn_refresh
        }
        
        if button_name in button_map:
            button_map[button_name].setEnabled(enabled)
            
    def highlight_button(self, button_name: str, highlighted: bool = True):
        """Выделить кнопку"""
        button_map = {
            'import': self.btn_import,
            'export': self.btn_export,
            'duplicates': self.btn_duplicates,
            'statistics': self.btn_statistics,
            'similar': self.btn_similar,
            'parsing': self.btn_parsing,
            'stopwords': self.btn_stopwords,
            'filters': self.btn_filters,
            'cross_minus': self.btn_cross_minus,
            'automation': self.btn_automation,
            'pipelines': self.btn_pipelines,
            'snapshots': self.btn_snapshots,
            'tags': self.btn_tags,
        }
        
        if button_name in button_map:
            button = button_map[button_name]
            if highlighted:
                button.setChecked(True)
            else:
                button.setChecked(False)
