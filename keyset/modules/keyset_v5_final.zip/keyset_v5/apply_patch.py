# -*- coding: utf-8 -*-
"""
Автоматический патчер для интеграции KeySet v5.0 в существующий MainWindow
"""

import os
import shutil
from pathlib import Path

def create_patched_main_py():
    """Создает патченную версию main.py с добавленной вкладкой KeySet v5.0"""
    
    # Пути файлов
    original_path = Path("/workspace/keyset/app/main.py")
    patched_path = Path("/workspace/keyset/app/main_patched.py")
    
    if not original_path.exists():
        raise FileNotFoundError(f"Оригинальный файл не найден: {original_path}")
    
    # Читаем оригинальный файл
    with open(original_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Ищем место для вставки импорта (после строки 37)
    import_insertion_point = content.find("ParsingTab = None\n\n")
    
    if import_insertion_point == -1:
        raise ValueError("Не найдено место для вставки импорта")
    
    # Добавляем импорт KeySet v5.0
    new_imports = """
try:
    from keyset_v5 import KeySetV5Tab
except ImportError:
    KeySetV5Tab = None
"""
    
    content = content[:import_insertion_point] + new_imports + content[import_insertion_point:]
    
    # Ищем место для добавления вкладки (после строки с добавлением масок)
    # Ищем: self.tabs.addTab(self.masks, "Маски")
    mask_tab_line = content.find('self.tabs.addTab(self.masks, "Маски")')
    
    if mask_tab_line == -1:
        raise ValueError("Не найдено место для добавления вкладки")
    
    # Находим конец строки с добавлением вкладки
    line_end = content.find('\n', mask_tab_line)
    
    # Добавляем код для новой вкладки
    v5_tab_code = """
        
        # Добавляем вкладку KeySet v5.0 если доступна
        if KeySetV5Tab:
            try:
                self.v5_tab = KeySetV5Tab()
                self.tabs.addTab(self.v5_tab, "KeySet v5.0 🚀")
                self.log_event("Добавлена вкладка KeySet v5.0")
            except Exception as e:
                self.log_event(f"Ошибка загрузки KeySet v5.0: {e}", level="ERROR")
        else:
            self.log_event("KeySet v5.0 не найден - используется только основной интерфейс", level="WARN")"""
    
    content = content[:line_end] + v5_tab_code + content[line_end:]
    
    # Ищем и обновляем метод _on_tab_changed
    on_tab_changed_start = content.find("def _on_tab_changed(self, index: int) -> None:")
    
    if on_tab_changed_start == -1:
        raise ValueError("Не найден метод _on_tab_changed")
    
    # Находим конец метода
    on_tab_changed_end = content.find("\n\n    def ", on_tab_changed_start)
    if on_tab_changed_end == -1:
        on_tab_changed_end = content.find("\n\n\n", on_tab_changed_start)
    if on_tab_changed_end == -1:
        raise ValueError("Не найден конец метода _on_tab_changed")
    
    # Заменяем метод на обновленную версию
    new_on_tab_changed = """def _on_tab_changed(self, index: int) -> None:
        """Обработчик переключения вкладок - скрывает KeysPanel для вкладки Парсинг и KeySet v5.0"""
        current_widget = self.tabs.widget(index)
        
        # Скрываем KeysPanel если открыта вкладка Парсинг или KeySet v5.0 
        if (hasattr(self, 'parsing') and current_widget == self.parsing) or \
           (hasattr(self, 'v5_tab') and current_widget == self.v5_tab):
            self.keys_panel.hide()
        else:
            self.keys_panel.show()"""
    
    content = content[:on_tab_changed_start] + new_on_tab_changed + content[on_tab_changed_end:]
    
    # Записываем патченную версию
    with open(patched_path, 'w', encoding='utf-8') as f:
        f.write(content)
    
    print(f"✅ Создан патченный файл: {patched_path}")
    print(f"📁 Оригинальный файл: {original_path}")
    print(f"🔧 Для применения патча замените оригинальный файл на патченный")
    
    return patched_path

def backup_original():
    """Создает резервную копию оригинального файла"""
    original_path = Path("/workspace/keyset/app/main.py")
    backup_path = Path("/workspace/keyset/app/main_original_backup.py")
    
    if original_path.exists():
        shutil.copy2(original_path, backup_path)
        print(f"📋 Резервная копия создана: {backup_path}")
    else:
        print("❌ Оригинальный файл не найден")

def apply_patch():
    """Применяет патч к оригинальному файлу"""
    try:
        # Создаем резервную копию
        backup_original()
        
        # Создаем патченную версию
        patched_path = create_patched_main_py()
        
        # Применяем патч (заменяем оригинал)
        original_path = Path("/workspace/keyset/app/main.py")
        shutil.copy2(patched_path, original_path)
        
        print(f"✅ Патч применен успешно!")
        print(f"🔄 Файл {original_path} обновлен")
        print(f"🚀 Перезапустите KeySet для использования KeySet v5.0")
        
    except Exception as e:
        print(f"❌ Ошибка применения патча: {e}")
        raise

if __name__ == "__main__":
    apply_patch()
