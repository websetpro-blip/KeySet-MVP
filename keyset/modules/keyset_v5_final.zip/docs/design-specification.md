# Дизайн-спецификация KeySet - Вкладка "Парсинг"

## 1. Обзор и философия дизайна

### 1.1 Стиль и позиционирование

KeySet — профессиональный desktop-инструмент для SEO-специалистов, работающих с ключевыми фразами. Дизайн следует принципам **функционального минимализма** с акцентом на производительность, читаемость и эффективность рабочего процесса.

**Визуальная философия:**
- **Профессиональная сдержанность**: нейтральная палитра без ярких акцентов
- **Информационная плотность**: максимум данных при сохранении читаемости
- **Четкая иерархия**: границы, контраст, структурированное пространство
- **Предсказуемость**: знакомые паттерны desktop-приложений (VS Code, Finder, Key Collector)

**Референсы:**
- **Desktop SEO-tools**: Key Collector, Screaming Frog, Ahrefs Desktop
- **IDE**: Visual Studio Code (панели, дерево файлов, toolbar)
- **Data tools**: Excel, Google Sheets (работа с таблицами)

### 1.2 Целевая аудитория

- **Профессия**: SEO-специалисты, контекстологи, маркетологи
- **Возраст**: 25-45 лет
- **Опыт**: средний и высокий уровень владения desktop-инструментами
- **Условия работы**: длительная работа (2-6 часов), несколько проектов, большие объемы данных (1000+ фраз)

### 1.3 Дизайн-принципы

1. **Читаемость превыше всего**: контраст ≥4.5:1, размер шрифта ≥13px
2. **Сканируемость**: чередующиеся строки, четкие разделители, группировка
3. **Плотность без перегрузки**: компактные элементы с достаточным breathing space
4. **Визуальная стабильность**: фиксированные размеры элементов интерфейса, нет неожиданных сдвигов
5. **Производительность**: минимум анимаций, быстрый отклик интерфейса

---

## 2. Design Tokens

### 2.1 Цветовая палитра

#### Основные цвета (Neutral Gray Scale)

| Токен | Значение | Hex | RGB | Использование |
|-------|----------|-----|-----|--------------|
| `gray-50` | Lightest | `#F9FAFB` | `249, 250, 251` | Фон app, secondary backgrounds |
| `gray-100` | Lighter | `#F3F4F6` | `243, 244, 246` | Таблица (четные строки), card backgrounds |
| `gray-200` | Light | `#E5E7EB` | `229, 231, 235` | Borders, dividers |
| `gray-300` | Medium-Light | `#D1D5DB` | `209, 213, 219` | Disabled borders, inactive elements |
| `gray-400` | Medium | `#9CA3AF` | `156, 163, 175` | Placeholder text, icons |
| `gray-500` | Medium-Dark | `#6B7280` | `107, 114, 128` | Secondary text, icons |
| `gray-600` | Dark | `#4B5563` | `75, 85, 99` | Primary text |
| `gray-700` | Darker | `#374151` | `55, 65, 81` | Headings, emphasis |
| `gray-800` | Darkest | `#1F2937` | `31, 41, 55` | Headers, high emphasis |
| `gray-900` | Black | `#111827` | `17, 24, 39` | Reserved (не используется для фона) |

#### Акцентные цвета (Blue - Primary Action)

| Токен | Значение | Hex | RGB | Использование |
|-------|----------|-----|-----|--------------|
| `blue-50` | Lightest | `#EFF6FF` | `239, 246, 255` | Hover backgrounds (subtle) |
| `blue-100` | Lighter | `#DBEAFE` | `219, 234, 254` | Selected row background |
| `blue-500` | Primary | `#3B82F6` | `59, 130, 246` | Primary buttons, links, active states |
| `blue-600` | Primary-Dark | `#2563EB` | `37, 99, 235` | Hover state for primary buttons |
| `blue-700` | Darkest | `#1D4ED8` | `29, 78, 216` | Active/pressed state |

#### Семантические цвета

| Токен | Hex | RGB | Использование |
|-------|-----|-----|--------------|
| `success-500` | `#10B981` | `16, 185, 129` | Успешные операции, статус "готово" |
| `success-100` | `#D1FAE5` | `209, 250, 229` | Success background (light) |
| `warning-500` | `#F59E0B` | `245, 158, 11` | Предупреждения |
| `warning-100` | `#FEF3C7` | `254, 243, 199` | Warning background (light) |
| `error-500` | `#EF4444` | `239, 68, 68` | Ошибки, кнопка удаления |
| `error-100` | `#FEE2E2` | `254, 226, 226` | Error background (light) |

#### Фоновые слои

| Слой | Токен | Hex | Описание |
|------|-------|-----|----------|
| **App Background** | `gray-50` | `#F9FAFB` | Основной фон приложения |
| **Surface (панели)** | `white` | `#FFFFFF` | Toolbar, панель групп, таблица |
| **Elevated** | `white` + `shadow-sm` | - | Модальные окна, dropdown |
| **Hover overlay** | `gray-100` | `#F3F4F6` | Hover state для строк |

### 2.2 Типографика

#### Шрифтовые семейства

| Назначение | Шрифт | Fallback |
|------------|-------|----------|
| **UI (основной)** | `Inter` | `-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif` |
| **Monospace (логи, код)** | `JetBrains Mono` | `'Consolas', 'Monaco', 'Courier New', monospace` |

**Подключение шрифтов:**
```html
<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
```

#### Шкала размеров

| Токен | Размер | Line Height | Использование |
|-------|--------|-------------|--------------|
| `text-xs` | `11px` | `16px (1.45)` | Вспомогательный текст, метки |
| `text-sm` | `13px` | `18px (1.38)` | Таблица (ячейки), кнопки, inputs |
| `text-base` | `14px` | `20px (1.43)` | Основной текст UI |
| `text-md` | `15px` | `22px (1.47)` | Заголовки секций, панели |
| `text-lg` | `16px` | `24px (1.5)` | Крупные заголовки |

#### Начертания (Font Weight)

| Токен | Значение | Использование |
|-------|----------|--------------|
| `font-normal` | `400` | Основной текст, значения в таблице |
| `font-medium` | `500` | Кнопки, активные элементы, заголовки колонок |
| `font-semibold` | `600` | Заголовки панелей, dropdown labels |
| `font-bold` | `700` | Редко (только для акцентов) |

### 2.3 Spacing (Отступы)

Система отступов основана на 4px сетке с акцентом на 8px шаг.

| Токен | Значение | Использование |
|-------|----------|--------------|
| `space-1` | `4px` | Минимальные отступы (icon padding) |
| `space-2` | `8px` | Между элементами в группе (toolbar buttons gap) |
| `space-3` | `12px` | Padding в кнопках, inputs (vertical) |
| `space-4` | `16px` | Padding в панелях (horizontal), gaps между секциями |
| `space-5` | `20px` | Padding в больших контейнерах |
| `space-6` | `24px` | Отступы между крупными блоками |
| `space-8` | `32px` | Большие отступы (редко) |

### 2.4 Border Radius

| Токен | Значение | Использование |
|-------|----------|--------------|
| `radius-none` | `0px` | Таблицы, панели (sharp edges для desktop-feel) |
| `radius-sm` | `4px` | Кнопки, inputs, чекбоксы |
| `radius-md` | `6px` | Dropdown меню, tooltips |
| `radius-lg` | `8px` | Модальные окна, большие карточки |

**Философия**: Sharp edges (0px radius) для основных панелей создает строгий desktop-вид, как VS Code/Figma. Скругления только для интерактивных элементов.

### 2.5 Shadows (Тени)

| Токен | Значение | Использование |
|-------|----------|--------------|
| `shadow-xs` | `0 1px 2px rgba(0,0,0,0.05)` | Subtle borders |
| `shadow-sm` | `0 1px 3px rgba(0,0,0,0.1), 0 1px 2px rgba(0,0,0,0.06)` | Buttons, inputs, cards |
| `shadow-md` | `0 4px 6px rgba(0,0,0,0.07), 0 2px 4px rgba(0,0,0,0.06)` | Dropdown меню |
| `shadow-lg` | `0 10px 15px rgba(0,0,0,0.1), 0 4px 6px rgba(0,0,0,0.05)` | Модальные окна |
| `shadow-inner` | `inset 0 2px 4px rgba(0,0,0,0.06)` | Активные inputs (focus) |

**Стратегия**: Минимальное использование теней. Основная граница между элементами — `border` в `gray-200/300`, тени только для elevated элементов.

### 2.6 Animation & Transitions

| Токен | Значение | Использование |
|-------|----------|--------------|
| `duration-fast` | `150ms` | Hover states, кнопки |
| `duration-base` | `200ms` | Модальные окна, dropdown |
| `duration-slow` | `300ms` | Slide panels, сложные transitions |
| `easing-default` | `cubic-bezier(0.4, 0, 0.2, 1)` | Универсальная кривая |
| `easing-in` | `cubic-bezier(0.4, 0, 1, 1)` | Closing animations |
| `easing-out` | `cubic-bezier(0, 0, 0.2, 1)` | Opening animations |

**Правило**: Анимировать ТОЛЬКО `opacity` и `transform` для производительности. Избегать анимации `width`, `height`, `margin`.

---

## 3. Компоненты UI

### 3.1 Toolbar (Верхняя панель)

#### Структура
```
┌─────────────────────────────────────────────────────────────┐
│ [+ Добавить] [✕ Удалить] [▼ Выделение] [Частота] ... [Готово] │
└─────────────────────────────────────────────────────────────┘
```

#### Спецификация

| Свойство | Значение |
|----------|----------|
| **Высота** | `56px` фиксированная |
| **Фон** | `white` |
| **Нижняя граница** | `1px solid gray-200` |
| **Padding** | `12px 16px` (vertical, horizontal) |
| **Gap между кнопками** | `8px` |
| **Выравнивание** | `flex`, `align-items: center`, `justify-content: flex-start` |

#### Кнопки в Toolbar

**Типы:**

1. **Primary (Добавить, Готово)**
   - Фон: `blue-500`
   - Текст: `white`, `font-medium`, `text-sm` (13px)
   - Padding: `10px 16px`
   - Border radius: `4px`
   - Shadow: `shadow-sm`
   - Hover: фон → `blue-600`
   - Active: фон → `blue-700`, легкое уменьшение (`scale: 0.98`)

2. **Secondary (Частота, Пакет, Прогноз, Очистить)**
   - Фон: `white`
   - Текст: `gray-700`, `font-medium`, `text-sm`
   - Border: `1px solid gray-300`
   - Padding: `10px 16px`
   - Border radius: `4px`
   - Shadow: `shadow-xs`
   - Hover: фон → `gray-50`, border → `gray-400`
   - Active: фон → `gray-100`

3. **Danger (Удалить)**
   - Фон: `white`
   - Текст: `error-500`, `font-medium`, `text-sm`
   - Border: `1px solid error-300`
   - Padding: `10px 16px`
   - Border radius: `4px`
   - Hover: фон → `error-50`, border → `error-400`
   - Active: фон → `error-100`

4. **Dropdown (Выделение ▼)**
   - Как Secondary + иконка chevron-down справа
   - Gap между текстом и иконкой: `6px`
   - Иконка размер: `16px`, цвет: `gray-500`

**Состояния:**

| Состояние | Transition | Transform |
|-----------|------------|-----------|
| **Default** | - | - |
| **Hover** | `background-color 150ms` | - |
| **Active** | `background-color 150ms, transform 100ms` | `scale(0.98)` |
| **Disabled** | - | `opacity: 0.5`, `cursor: not-allowed` |

#### Иконки

- Источник: **Lucide Icons** (SVG, 16-20px)
- Размер: `16px` для inline icons, `20px` для standalone
- Цвет: наследуется от родителя (`currentColor`)
- Стиль: outline (тонкие линии)

### 3.2 Таблица фраз

#### Структура

```
┌─────────────────────────────────────────────────────────────┐
│ ☐ │ №  │ Фраза                 │ ws  │ qws │ bws │ Статус │
├───┼────┼──────────────────────┼─────┼─────┼─────┼────────┤
│ ☐ │ 1  │ косметика для лица   │ 120 │ 45  │ 30  │   ✓    │
│ ☑ │ 2  │ маляр в москве       │ 80  │ 22  │ 15  │   ✓    │
│ ☐ │ 3  │ черный диван         │ 250 │ 90  │ 70  │   ✓    │
└─────────────────────────────────────────────────────────────┘
```

#### Спецификация таблицы

| Свойство | Значение |
|----------|----------|
| **Фон** | `white` |
| **Border** | `1px solid gray-200` (вокруг таблицы) |
| **Высота строки** | `36px` (компактная для 1000+ строк) |
| **Padding ячейки** | `8px 12px` |
| **Вертикальные разделители** | `1px solid gray-200` между колонками |

#### Заголовок таблицы (thead)

| Свойство | Значение |
|----------|----------|
| **Фон** | `gray-100` |
| **Текст** | `gray-700`, `font-semibold`, `text-sm` (13px) |
| **Высота** | `40px` |
| **Border-bottom** | `2px solid gray-300` (толще для акцента) |
| **Hover** | `gray-200` (для сортируемых колонок) |
| **Cursor** | `pointer` (для сортируемых) |

**Сортировка:**
- Иконка: `↑` (`ArrowUp`) или `↓` (`ArrowDown`) рядом с текстом
- Размер иконки: `14px`
- Цвет иконки: `gray-500` (неактивная), `blue-500` (активная)
- Gap между текстом и иконкой: `4px`

#### Строки данных (tbody)

**Чередующиеся цвета:**
- Четные строки: `white`
- Нечетные строки: `gray-50` (subtle alternation)

**Состояния строки:**

| Состояние | Фон | Border | Прочее |
|-----------|-----|--------|--------|
| **Default** | Чередующийся | - | - |
| **Hover** | `blue-50` | - | `transition: background-color 100ms` |
| **Selected** | `blue-100` | `2px solid blue-500` (left border) | Checkbox checked |
| **Editing** | `white` | `2px solid blue-500` (вокруг ячейки) | Input field visible |

#### Колонки

| Колонка | Ширина | Выравнивание | Описание |
|---------|--------|-------------|----------|
| **☐ (Checkbox)** | `48px` | Center | Чекбокс для выбора строки |
| **№** | `56px` | Right | Порядковый номер |
| **Фраза** | `flex: 1` (min: 200px) | Left | Основной текст фразы |
| **ws** | `80px` | Right | Частотность Wordstat |
| **qws** | `80px` | Right | Частотность в кавычках |
| **bws** | `80px` | Right | Базовая частотность |
| **Статус** | `80px` | Center | Иконка статуса |

**Числовые значения:**
- Цвет: `gray-600`
- Шрифт: `font-normal`, `text-sm`
- Формат: разделитель тысяч — пробел (`12 345`)

**Статус (иконка):**
- Готово: `✓` зеленая (`success-500`), размер `16px`
- В процессе: `○` серая (`gray-400`), размер `16px`
- Ошибка: `✕` красная (`error-500`), размер `16px`

#### Чекбоксы

| Свойство | Значение |
|----------|----------|
| **Размер** | `16px × 16px` |
| **Border** | `1.5px solid gray-300` |
| **Border radius** | `3px` |
| **Checked: фон** | `blue-500` |
| **Checked: иконка** | Белая галочка `✓`, `12px` |
| **Hover** | Border → `blue-500` |
| **Focus** | `outline: 2px solid blue-300`, `outline-offset: 2px` |

#### Inline Editing (двойной клик)

| Свойство | Значение |
|----------|----------|
| **Input фон** | `white` |
| **Border** | `2px solid blue-500` |
| **Padding** | `6px 10px` |
| **Font** | Наследуется от ячейки |
| **Focus** | `outline: none`, `shadow-inner` |
| **Escape** | Отменить изменения, вернуть исходное значение |
| **Enter** | Сохранить, blur |

### 3.3 Панель управления группами (правая часть)

#### Структура

```
┌──────────────────────────────┐
│ Управление группами          │
│ [+] [-] [S] [⟲]             │
├──────────────────────────────┤
│ ☑ Группа 1 (15)              │
│   ├─ Подгруппа А (8)         │
│   └─ Подгруппа Б (7)         │
│ ☐ Группа 2 (23)              │
│ ☐ Группа 3 (42)              │
└──────────────────────────────┘
```

#### Спецификация

| Свойство | Значение |
|----------|----------|
| **Ширина** | `30%` (минимум `280px`, максимум `400px`) |
| **Фон** | `white` |
| **Border-left** | `1px solid gray-200` |
| **Resizable** | Да, handle на левой границе (`4px` ширина, hover: `gray-400`) |

#### Заголовок панели

| Свойство | Значение |
|----------|----------|
| **Текст** | "Управление группами", `gray-800`, `font-semibold`, `text-md` (15px) |
| **Padding** | `16px` |
| **Border-bottom** | `1px solid gray-200` |

#### Мини-toolbar

| Свойство | Значение |
|----------|----------|
| **Padding** | `8px 12px` |
| **Border-bottom** | `1px solid gray-200` |
| **Gap между кнопками** | `4px` |
| **Кнопки размер** | `28px × 28px` (квадратные icon buttons) |
| **Кнопки фон** | `transparent`, hover: `gray-100`, active: `gray-200` |
| **Иконки размер** | `16px`, цвет: `gray-600` |
| **Border radius** | `4px` |

**Кнопки:**
- `[+]` Добавить группу
- `[-]` Удалить группу
- `[S]` Сохранить порядок
- `[⟲]` Обновить дерево

#### Дерево групп

**Узел дерева:**

| Свойство | Значение |
|----------|----------|
| **Высота строки** | `32px` |
| **Padding** | `6px 12px` |
| **Indent** | `20px` на уровень вложенности |
| **Hover** | Фон → `gray-50` |
| **Selected** | Фон → `blue-50`, border-left: `3px solid blue-500` |
| **Active** | Фон → `blue-100` |

**Структура узла:**
```
[☐] [▸/▾] [📁/📄] Название группы (count)
```

- **Checkbox**: `14px`, как в таблице, слева
- **Chevron** (▸/▾): `12px`, цвет: `gray-500`, есть только у папок
- **Иконка**: `16px`, 📁 для папок (`gray-500`), 📄 для конечных узлов (`gray-400`)
- **Текст**: `font-medium`, `text-sm` (13px), `gray-700`
- **Счетчик** (count): `font-normal`, `text-xs` (11px), `gray-500`, в скобках

**Состояния узла:**

| Состояние | Описание |
|-----------|----------|
| **Collapsed** | Chevron `▸`, children скрыты |
| **Expanded** | Chevron `▾`, children видны |
| **Dragging** | `opacity: 0.5`, `cursor: grabbing` |
| **Drop target** | Подсветка: `border: 2px dashed blue-300`, фон: `blue-50` |

**Inline Editing (переименование):**
- Двойной клик на названии группы
- Input появляется на месте текста
- Border: `1px solid blue-500`
- Padding: `4px 6px`
- Font: `text-sm`, `font-medium`
- Enter: сохранить, Escape: отменить

**Контекстное меню (ПКМ):**
- Фон: `white`
- Border: `1px solid gray-200`
- Shadow: `shadow-md`
- Border radius: `6px`
- Padding: `4px`
- Пункты меню:
  - Padding: `8px 12px`
  - Font: `text-sm`, `gray-700`
  - Hover: фон → `gray-100`
  - Gap между иконкой и текстом: `8px`
  - Иконка размер: `16px`

**Пункты меню:**
- ✏️ Переименовать
- 🗑️ Удалить
- ➕ Добавить подгруппу
- 📋 Скопировать
- ✂️ Вырезать
- 📌 Вставить

### 3.4 Журнал активности (нижняя часть)

#### Структура

```
┌──────────────────────────────────────────────────────────────┐
│ Журнал активности                                  [Очистить] │
├──────────────────────────────────────────────────────────────┤
│ [00:05:28] Создана группа "SEO фразы"                        │
│ [00:05:30] Парсинг запущен для 150 фраз                      │
│ [00:05:35] Добавлено 150 фраз в таблицу                      │
└──────────────────────────────────────────────────────────────┘
```

#### Спецификация

| Свойство | Значение |
|----------|----------|
| **Высота** | `140px` фиксированная |
| **Фон** | `gray-900` (темный для контраста) |
| **Border-top** | `1px solid gray-700` |
| **Padding** | `12px 16px` |
| **Overflow** | `auto` (scroll при переполнении) |
| **Auto-scroll** | Да, к последнему сообщению |

#### Заголовок

| Свойство | Значение |
|----------|----------|
| **Текст** | "Журнал активности", `gray-300`, `font-semibold`, `text-sm` |
| **Кнопка "Очистить"** | Справа, `text-xs`, `gray-400`, hover: `gray-200`, cursor: pointer |
| **Padding-bottom** | `8px` |
| **Border-bottom** | `1px solid gray-700` |

#### Записи лога

| Свойство | Значение |
|----------|----------|
| **Font** | `JetBrains Mono`, `text-xs` (11px), `font-normal` |
| **Цвет текста** | `gray-300` |
| **Line height** | `18px` (1.64) |
| **Padding между записями** | `4px` |

**Формат записи:**
```
[HH:MM:SS] Текст события
```

- **Timestamp** `[HH:MM:SS]`: цвет `gray-500`, моноширинный
- **Текст события**: цвет зависит от типа события

**Типы событий (цветовое кодирование):**

| Тип | Цвет | Примеры |
|-----|------|---------|
| **Info** | `gray-300` | Создана группа, Добавлено фраз |
| **Success** | `success-400` | Парсинг завершен, Экспорт выполнен |
| **Warning** | `warning-400` | Дубликаты найдены, Превышен лимит |
| **Error** | `error-400` | Ошибка парсинга, Сбой сохранения |

### 3.5 Модальные окна

#### Спецификация

| Свойство | Значение |
|----------|----------|
| **Overlay фон** | `rgba(17, 24, 39, 0.5)` (gray-900 с прозрачностью) |
| **Modal фон** | `white` |
| **Border radius** | `8px` |
| **Shadow** | `shadow-lg` |
| **Padding** | `24px` |
| **Max width** | `500px` (для форм), `800px` (для списков) |
| **Min height** | `200px` |

#### Структура

```
┌────────────────────────────────────┐
│ Заголовок модалки             [✕] │
├────────────────────────────────────┤
│                                    │
│ Контент                            │
│                                    │
├────────────────────────────────────┤
│          [Отмена]  [Подтвердить]  │
└────────────────────────────────────┘
```

**Заголовок:**
- Текст: `gray-800`, `font-semibold`, `text-lg` (16px)
- Кнопка закрытия [✕]: `24px × 24px`, `gray-400`, hover: `gray-600`
- Border-bottom: `1px solid gray-200`
- Padding-bottom: `16px`

**Кнопки (футер):**
- Выравнивание: справа (`justify-content: flex-end`)
- Gap: `12px`
- Padding-top: `16px`
- Border-top: `1px solid gray-200`

### 3.6 Input Fields (Поля ввода)

#### Спецификация

| Свойство | Значение |
|----------|----------|
| **Высота** | `40px` |
| **Padding** | `10px 12px` |
| **Font** | `text-sm` (13px), `font-normal`, `gray-700` |
| **Фон** | `white` |
| **Border** | `1px solid gray-300` |
| **Border radius** | `4px` |
| **Placeholder цвет** | `gray-400` |

**Состояния:**

| Состояние | Border | Фон | Shadow | Прочее |
|-----------|--------|-----|--------|--------|
| **Default** | `gray-300` | `white` | - | - |
| **Hover** | `gray-400` | `white` | - | - |
| **Focus** | `blue-500` (2px) | `white` | `shadow-inner` | `outline: none` |
| **Error** | `error-500` (2px) | `error-50` | - | Error message ниже |
| **Disabled** | `gray-200` | `gray-50` | - | `opacity: 0.6`, `cursor: not-allowed` |

**Label:**
- Font: `text-sm`, `font-medium`, `gray-700`
- Padding-bottom: `6px`
- Required indicator (*): `error-500`

**Error message:**
- Font: `text-xs`, `gray-600` (или `error-600` для критичных)
- Padding-top: `4px`
- Иконка: `⚠️` (`16px`, `error-500`)

### 3.7 Dropdown меню

#### Спецификация

| Свойство | Значение |
|----------|----------|
| **Фон** | `white` |
| **Border** | `1px solid gray-200` |
| **Border radius** | `6px` |
| **Shadow** | `shadow-md` |
| **Padding** | `4px` |
| **Max height** | `300px` (scroll при переполнении) |

**Пункт меню:**

| Свойство | Значение |
|----------|----------|
| **Padding** | `8px 12px` |
| **Font** | `text-sm`, `gray-700` |
| **Border radius** | `4px` |
| **Hover** | Фон → `gray-100` |
| **Active/Selected** | Фон → `blue-50`, текст → `blue-600`, иконка ✓ справа |
| **Disabled** | Текст → `gray-400`, cursor: `not-allowed` |

**Разделитель:**
- Border: `1px solid gray-200`
- Margin: `4px 0`

**Иконки в меню:**
- Размер: `16px`
- Gap от текста: `8px`
- Цвет: `gray-500` (или наследуется)

### 3.8 Tooltips

#### Спецификация

| Свойство | Значение |
|----------|----------|
| **Фон** | `gray-900` |
| **Текст** | `white`, `text-xs` (11px), `font-normal` |
| **Padding** | `6px 10px` |
| **Border radius** | `6px` |
| **Shadow** | `shadow-sm` |
| **Max width** | `220px` |
| **Arrow** | `4px` треугольник в цвет фона |

**Позиционирование:**
- Предпочтительно: сверху (top)
- Offset от элемента: `8px`
- Появление: `delay: 500ms`
- Transition: `opacity 150ms`

---

## 4. Layout & Responsive

### 4.1 Общая структура

```
┌────────────────────────────────────────────────────────────┐
│ TOOLBAR (56px height)                                      │
├────────────────────────────┬───────────────────────────────┤
│                            │                               │
│ ТАБЛИЦА ФРАЗ (70%)         │ ПАНЕЛЬ ГРУПП (30%)            │
│                            │                               │
│                            │                               │
│                            │                               │
├────────────────────────────┴───────────────────────────────┤
│ ЖУРНАЛ АКТИВНОСТИ (140px height)                           │
└────────────────────────────────────────────────────────────┘
```

### 4.2 Размеры и пропорции

| Элемент | Размер | Constraints |
|---------|--------|-------------|
| **Toolbar** | `56px` высота | Фиксированная |
| **Таблица** | `70%` ширины | Минимум `600px` |
| **Панель групп** | `30%` ширины | Минимум `280px`, максимум `400px`, resizable |
| **Журнал** | `140px` высота | Фиксированная |
| **Main area height** | `calc(100vh - 56px - 140px)` | Динамическая, заполняет пространство |

### 4.3 Responsive Breakpoints

**Минимальное разрешение: 1024px (desktop-only)**

Приложение НЕ адаптируется под мобильные устройства. Ориентация на desktop:

| Разрешение | Layout |
|------------|--------|
| **≥1920px** | Оптимальное отображение, все элементы в комфортных размерах |
| **1366px - 1920px** | Базовое отображение, уменьшение padding/gaps |
| **1024px - 1366px** | Минимальное отображение, сжатие панели групп |
| **<1024px** | Не поддерживается, показать предупреждение "Минимальное разрешение 1024px" |

### 4.4 Resizable разделитель

**Между таблицей и панелью групп:**

| Свойство | Значение |
|----------|----------|
| **Ширина handle** | `4px` |
| **Цвет** | `transparent`, hover: `blue-300` |
| **Cursor** | `col-resize` |
| **Drag цвет** | `blue-500` (показать вертикальную линию) |
| **Min left width** | `600px` |
| **Min right width** | `280px` |
| **Max right width** | `400px` |

---

## 5. Интерактивность и состояния

### 5.1 Keyboard Navigation

**Глобальные горячие клавиши:**

| Комбинация | Действие |
|------------|----------|
| `Ctrl/Cmd + N` | Добавить новую фразу |
| `Ctrl/Cmd + A` | Выбрать все строки в таблице |
| `Ctrl/Cmd + D` | Удалить выбранные строки |
| `Ctrl/Cmd + Z` | Отменить (Undo) |
| `Ctrl/Cmd + Shift + Z` | Повторить (Redo) |
| `Ctrl/Cmd + F` | Фокус на поиск |
| `Escape` | Закрыть модальное окно / снять выделение |

**В таблице:**

| Клавиша | Действие |
|---------|----------|
| `↑` `↓` | Навигация по строкам |
| `Space` | Toggle checkbox текущей строки |
| `Enter` | Редактировать выбранную ячейку (если поддерживается) |
| `Shift + ↑/↓` | Multiple selection |

**В дереве групп:**

| Клавиша | Действие |
|---------|----------|
| `↑` `↓` | Навигация по узлам |
| `→` | Развернуть узел |
| `←` | Свернуть узел |
| `Space` | Toggle checkbox узла |
| `F2` | Переименовать узел |
| `Delete` | Удалить узел |

### 5.2 Focus indicators

| Элемент | Focus стиль |
|---------|-------------|
| **Кнопки** | `outline: 2px solid blue-300`, `outline-offset: 2px` |
| **Inputs** | `border: 2px solid blue-500`, `shadow-inner` |
| **Чекбоксы** | `outline: 2px solid blue-300`, `outline-offset: 2px` |
| **Строки таблицы** | `box-shadow: inset 0 0 0 2px blue-300` |
| **Узлы дерева** | `background: blue-50`, `border-left: 3px solid blue-500` |

**Accessibility:**
- Все focus indicators WCAG AAA compliant
- Keyboard navigation: tab order логичен
- Skip links: "Skip to table", "Skip to groups"

### 5.3 Loading states

**Индикатор загрузки (Spinner):**

| Свойство | Значение |
|----------|----------|
| **Размер** | `20px` (inline), `40px` (center) |
| **Цвет** | `blue-500` |
| **Animation** | `rotate 1s linear infinite` |
| **Тип** | Circular spinner (border-top rotating) |

**Skeleton screens (для таблицы при первой загрузке):**
- Фон строк: `gray-200` пульсация
- Анимация: `pulse 1.5s ease-in-out infinite`
- Количество строк: 10-15

**Overlay loading (для действий):**
- Фон: `rgba(255,255,255,0.8)` поверх контента
- Spinner: центрированный
- Текст: "Загрузка..." под spinner, `text-sm`, `gray-600`

### 5.4 Error states

**Inline ошибки (в формах):**
- Красная border на input (`error-500`)
- Иконка `⚠️` слева от текста ошибки
- Текст: `text-xs`, `error-600`

**Toast notifications:**

| Свойство | Значение |
|----------|----------|
| **Позиция** | Top-right, `24px` от края |
| **Фон** | `white` |
| **Border-left** | `4px solid [color]` (success: зеленый, error: красный, warning: оранжевый) |
| **Shadow** | `shadow-lg` |
| **Border radius** | `6px` |
| **Padding** | `16px` |
| **Max width** | `400px` |
| **Auto-dismiss** | 5 секунд (error: 7 секунд) |
| **Transition** | Slide-in from right, fade-out |

**Структура toast:**
```
[Иконка] Заголовок
         Описание ошибки
                    [✕]
```

---

## 6. Accessibility (WCAG 2.1 AA)

### 6.1 Цветовой контраст

**Проверенные пары (минимум 4.5:1):**

| Фон | Текст | Контраст | Применение |
|-----|-------|----------|------------|
| `white` | `gray-600` | 5.74:1 ✅ | Основной текст |
| `white` | `gray-700` | 7.67:1 ✅ | Заголовки |
| `gray-50` | `gray-600` | 5.43:1 ✅ | Текст на альтернативном фоне |
| `blue-500` | `white` | 4.87:1 ✅ | Кнопки primary |
| `gray-900` | `gray-300` | 8.92:1 ✅ | Журнал активности |

### 6.2 ARIA attributes

**Таблица:**
```html
<table role="grid" aria-label="Таблица ключевых фраз">
  <thead>
    <tr role="row">
      <th role="columnheader" aria-sort="ascending">№</th>
      <th role="columnheader" aria-sort="none">Фраза</th>
    </tr>
  </thead>
  <tbody>
    <tr role="row" aria-selected="true">
      <td role="gridcell">1</td>
      <td role="gridcell">косметика для лица</td>
    </tr>
  </tbody>
</table>
```

**Дерево групп:**
```html
<div role="tree" aria-label="Дерево групп">
  <div role="treeitem" aria-expanded="true" aria-level="1">
    <input type="checkbox" aria-label="Выбрать группу 1">
    <span>Группа 1</span>
  </div>
</div>
```

**Кнопки:**
```html
<button aria-label="Добавить фразу" title="Добавить фразу">
  <svg>...</svg> Добавить
</button>
```

### 6.3 Screen readers

- Все интерактивные элементы имеют `aria-label` или `title`
- Иконки без текста: `aria-label` обязателен
- Динамический контент: `aria-live="polite"` для журнала
- Модальные окна: `aria-modal="true"`, фокус ловушка
- Форма: label связаны с input через `for`/`id`

### 6.4 Motion preferences

```css
@media (prefers-reduced-motion: reduce) {
  * {
    animation-duration: 0.01ms !important;
    transition-duration: 0.01ms !important;
  }
}
```

---

## 7. Технические рекомендации

### 7.1 Оптимизация производительности

**Для таблицы с 1000+ строк:**

1. **Виртуализация обязательна**: использовать TanStack Table + react-window
2. **Мемоизация компонентов**: `React.memo` для строк таблицы
3. **Селективные обновления**: Zustand селекторы для подписки только на нужные части state
4. **Debounce поиска**: 300ms для фильтрации таблицы
5. **Lazy loading**: загружать данные порциями (pagination или infinite scroll)

**Для дерева групп:**

1. **react-arborist** с виртуализацией (10,000+ узлов)
2. **Мемоизация узлов**: не рендерить скрытые (collapsed) узлы
3. **Flatten data structure**: хранить группы в плоской структуре `Record<id, Group>` в Zustand

### 7.2 CSS стратегия

**Tailwind CSS Utility-First:**

```html
<!-- Пример кнопки primary -->
<button class="
  px-4 py-2.5 
  bg-blue-500 hover:bg-blue-600 active:bg-blue-700 
  text-white text-sm font-medium 
  rounded 
  shadow-sm 
  transition-colors duration-150 
  active:scale-98
">
  Добавить
</button>
```

**Кастомные классы (для повторяющихся паттернов):**

```css
/* tailwind.config.js - extend */
module.exports = {
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
      colors: {
        gray: { /* custom gray scale */ },
        blue: { /* custom blue scale */ },
      },
      spacing: {
        /* 4px grid */ 
      },
    },
  },
}
```

### 7.3 Icon system

**Библиотека: Lucide React**

```tsx
import { Plus, Trash2, ChevronDown, Check } from 'lucide-react';

<Plus className="w-4 h-4 text-gray-600" />
```

**Размеры:**
- `w-4 h-4` (16px) - inline icons
- `w-5 h-5` (20px) - standalone icons в кнопках
- `w-6 h-6` (24px) - крупные иконки (модальные окна)

**Цвет:** Использовать `currentColor` для наследования цвета от родителя.

### 7.4 Z-index слои

| Слой | Z-index | Элементы |
|------|---------|----------|
| **Base** | `0` | Таблицы, панели |
| **Dropdown** | `10` | Dropdown меню, tooltips |
| **Sticky** | `20` | Sticky headers |
| **Modal Overlay** | `40` | Overlay для модальных окон |
| **Modal Content** | `50` | Модальные окна |
| **Toast** | `60` | Уведомления |

---

## 8. Примеры состояний компонентов

### 8.1 Кнопка Primary (все состояния)

| Состояние | Внешний вид |
|-----------|-------------|
| **Default** | Фон: `blue-500`, текст: `white`, shadow: `shadow-sm` |
| **Hover** | Фон: `blue-600`, shadow: `shadow-sm` |
| **Active** | Фон: `blue-700`, transform: `scale(0.98)` |
| **Focus** | Outline: `2px solid blue-300`, offset: `2px` |
| **Disabled** | Фон: `gray-300`, текст: `gray-500`, cursor: `not-allowed`, opacity: `0.6` |
| **Loading** | Spinner внутри, текст: "Загрузка...", disabled |

### 8.2 Строка таблицы (все состояния)

| Состояние | Внешний вид |
|-----------|-------------|
| **Default** | Фон: чередующийся (`white` / `gray-50`) |
| **Hover** | Фон: `blue-50`, cursor: `pointer` |
| **Selected** | Фон: `blue-100`, border-left: `2px solid blue-500`, checkbox: checked |
| **Editing** | Ячейка с input, border: `2px solid blue-500`, фон: `white` |
| **Focus** | Box-shadow: `inset 0 0 0 2px blue-300` |

### 8.3 Узел дерева (все состояния)

| Состояние | Внешний вид |
|-----------|-------------|
| **Default** | Фон: `transparent`, текст: `gray-700` |
| **Hover** | Фон: `gray-50` |
| **Selected** | Фон: `blue-50`, border-left: `3px solid blue-500` |
| **Active** | Фон: `blue-100` |
| **Dragging** | Opacity: `0.5`, cursor: `grabbing` |
| **Drop target** | Border: `2px dashed blue-300`, фон: `blue-50` |
| **Editing** | Input на месте текста, border: `1px solid blue-500` |

---

## 9. Финальные замечания

### 9.1 Чего ИЗБЕГАТЬ

❌ **Яркие, насыщенные цвета** - отвлекают от данных
❌ **Избыточные анимации** - замедляют работу
❌ **Мелкий шрифт** (<13px) - ухудшает читаемость
❌ **Слишком широкие таблицы** - трудно сканировать
❌ **Плоские, без границ** - теряется структура
❌ **Эмодзи как UI-иконки** - непрофессионально (только в контенте логов)

### 9.2 На что делать АКЦЕНТ

✅ **Читаемость** - контраст, размер шрифта, межстрочный интервал
✅ **Сканируемость** - чередующиеся строки, четкие границы, группировка
✅ **Предсказуемость** - знакомые паттерны, консистентность
✅ **Производительность** - виртуализация, мемоизация, оптимизация рендеринга
✅ **Доступность** - keyboard navigation, ARIA, контраст

### 9.3 Приоритеты

1. **Функциональность** - инструмент должен работать быстро и стабильно
2. **Читаемость** - данные должны легко восприниматься
3. **Эффективность** - минимум кликов для типичных задач
4. **Эстетика** - приятный, но не отвлекающий дизайн

---

**Версия документа:** 1.0  
**Дата:** 2025-10-31  
**Статус:** Готово к реализации
